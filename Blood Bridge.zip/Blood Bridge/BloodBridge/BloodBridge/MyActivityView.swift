import SwiftUI
import Supabase

// MARK: - Activity Role

enum ActivityRole {
    case donor
    case healthcareRequester
}

// MARK: - Activity Model

struct BloodBridgeActivity: Identifiable {
    let id: UUID
    let title: String
    let subtitle: String
    let bloodGroup: String
    let date: String
    let status: String
    let units: Int
}

// MARK: - Supabase Response Model

private struct ActivityResponse: Decodable {
    let id: UUID
    let request_id: UUID
    let donor_id: UUID
    let status: String
}

// MARK: - My Activity Page

struct MyActivityView: View {
    let role: ActivityRole

    @State private var selectedFilter = "All"
    @State private var activities: [BloodBridgeActivity] = []
    @State private var isLoading = false
    @State private var errorMessage: String?

    private let backgroundColor = Color(
        red: 0.035, green: 0.035, blue: 0.045
    )

    private let cardColor = Color(
        red: 0.09, green: 0.09, blue: 0.11
    )

    private let bloodRed = Color(
        red: 0.88, green: 0.12, blue: 0.20
    )

    private let gold = Color(
        red: 0.80, green: 0.66, blue: 0.40
    )

    private var isDonor: Bool {
        role == .donor
    }

    private var pageTitle: String {
        isDonor ? "My Donations" : "My Blood Requests"
    }

    private var pageSubtitle: String {
        isDonor
        ? "Track your donation offers and their progress."
        : "Manage the blood requests created by your organization."
    }

    private var filters: [String] {
        isDonor
        ? ["All", "Pending", "Accepted", "Declined", "Completed"]
        : ["All", "Open", "In Progress", "Fulfilled", "Cancelled"]
    }

    private var filteredActivities: [BloodBridgeActivity] {
        guard selectedFilter != "All" else {
            return activities
        }

        return activities.filter {
            $0.status.caseInsensitiveCompare(selectedFilter) == .orderedSame
        }
    }

    private var pendingCount: Int {
        activities.filter { activity in
            if isDonor {
                return activity.status.lowercased() == "pending"
            }

            return activity.status.lowercased() == "open"
        }.count
    }

    var body: some View {
        ZStack {
            backgroundColor
                .ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    header
                    summaryCard
                    filterSection
                    activitySection
                }
                .padding(20)
                .padding(.bottom, 24)
            }
            .refreshable {
                await loadActivities()
            }
        }
        .navigationTitle(pageTitle)
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(backgroundColor, for: .navigationBar)
        .toolbarBackground(.visible, for: .navigationBar)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .tint(gold)
        .task {
            await loadActivities()
        }
    }

    // MARK: Header

    private var header: some View {
        VStack(alignment: .leading, spacing: 9) {
            Text("BLOODBRIDGE")
                .font(.system(size: 12, weight: .bold))
                .tracking(3)
                .foregroundStyle(gold)

            Text(pageTitle)
                .font(.system(size: 29, weight: .bold))
                .foregroundStyle(.white)

            Text(pageSubtitle)
                .font(.subheadline)
                .foregroundStyle(.white.opacity(0.65))

            Button {
                Task {
                    await loadActivities()
                }
            } label: {
                Label("Refresh activity", systemImage: "arrow.clockwise")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(gold)
            }
            .disabled(isLoading)
            .padding(.top, 3)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.top, 12)
    }

    // MARK: Summary

    private var summaryCard: some View {
        HStack(spacing: 15) {
            Image(systemName: isDonor ? "heart.fill" : "cross.case.fill")
                .font(.system(size: 27))
                .foregroundStyle(bloodRed)
                .frame(width: 58, height: 58)
                .background(bloodRed.opacity(0.12))
                .clipShape(RoundedRectangle(cornerRadius: 16))

            VStack(alignment: .leading, spacing: 5) {
                Text("Total \(isDonor ? "Offers" : "Requests")")
                    .font(.subheadline)
                    .foregroundStyle(.white.opacity(0.7))

                Text("\(activities.count)")
                    .font(.system(size: 28, weight: .bold))
                    .foregroundStyle(.white)
            }

            Spacer()

            VStack(alignment: .trailing, spacing: 5) {
                Text("Pending")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.65))

                Text("\(pendingCount)")
                    .font(.system(size: 21, weight: .bold))
                    .foregroundStyle(gold)
            }
        }
        .padding(17)
        .background(cardColor)
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .overlay {
            RoundedRectangle(cornerRadius: 18)
                .stroke(Color.white.opacity(0.07), lineWidth: 1)
        }
    }

    // MARK: Filters

    private var filterSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Filter Activity")
                .font(.headline)
                .foregroundStyle(.white)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 9) {
                    ForEach(filters, id: \.self) { filter in
                        Button {
                            selectedFilter = filter
                        } label: {
                            Text(filter)
                                .font(.system(size: 12, weight: .semibold))
                                .padding(.horizontal, 14)
                                .padding(.vertical, 10)
                                .foregroundStyle(
                                    selectedFilter == filter
                                    ? Color.white
                                    : Color.white.opacity(0.7)
                                )
                                .background(
                                    selectedFilter == filter
                                    ? bloodRed
                                    : cardColor
                                )
                                .clipShape(Capsule())
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    }

    // MARK: Activity List

    private var activitySection: some View {
        VStack(alignment: .leading, spacing: 13) {
            HStack {
                Text("Recent Activity")
                    .font(.headline)
                    .foregroundStyle(.white)

                Spacer()

                Text("\(filteredActivities.count) records")
                    .font(.caption)
                    .foregroundStyle(gold)
            }

            if isLoading && activities.isEmpty {
                ProgressView("Loading activity...")
                    .tint(gold)
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding(28)
                    .background(cardColor)
                    .clipShape(RoundedRectangle(cornerRadius: 18))

            } else if let errorMessage {
                VStack(spacing: 12) {
                    Image(systemName: "exclamationmark.triangle")
                        .font(.system(size: 30))
                        .foregroundStyle(gold)

                    Text("Couldn't load activity")
                        .font(.headline)
                        .foregroundStyle(.white)

                    Text(errorMessage)
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.7))
                        .multilineTextAlignment(.center)
                        .textSelection(.enabled)

                    Button("Try Again") {
                        Task {
                            await loadActivities()
                        }
                    }
                    .foregroundStyle(gold)
                }
                .frame(maxWidth: .infinity)
                .padding(24)
                .background(cardColor)
                .clipShape(RoundedRectangle(cornerRadius: 18))

            } else if filteredActivities.isEmpty {
                emptyState

            } else {
                ForEach(filteredActivities) { activity in
                    activityCard(activity)
                }
            }
        }
    }

    private var emptyState: some View {
        VStack(spacing: 12) {
            Image(systemName: "tray")
                .font(.system(size: 32))
                .foregroundStyle(gold)

            Text("No activity found")
                .font(.headline)
                .foregroundStyle(.white)

            Text(
                isDonor
                ? "Your donation offers will appear here."
                : "Your blood requests will appear here."
            )
            .font(.subheadline)
            .foregroundStyle(.white.opacity(0.65))
            .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(28)
        .background(cardColor)
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }

    // MARK: Activity Card

    private func activityCard(
        _ activity: BloodBridgeActivity
    ) -> some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack(alignment: .top, spacing: 12) {
                VStack(spacing: 5) {
                    Image(systemName: "drop.fill")
                        .font(.system(size: 21))
                        .foregroundStyle(bloodRed)

                    Text(activity.bloodGroup)
                        .font(.system(size: 14, weight: .bold))
                        .foregroundStyle(.white)
                }
                .frame(width: 60, height: 68)
                .background(bloodRed.opacity(0.12))
                .clipShape(RoundedRectangle(cornerRadius: 13))

                VStack(alignment: .leading, spacing: 6) {
                    Text(activity.title)
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(.white)

                    Label(
                        activity.subtitle,
                        systemImage: "mappin.and.ellipse"
                    )
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.65))
                }

                Spacer(minLength: 0)

                statusBadge(activity.status)
            }

            Rectangle()
                .fill(Color.white.opacity(0.08))
                .frame(height: 1)

            HStack {
                Label(
                    "\(activity.units) unit\(activity.units == 1 ? "" : "s")",
                    systemImage: "cross.case"
                )

                Spacer()

                Label(activity.date, systemImage: "calendar")
                    .multilineTextAlignment(.trailing)
            }
            .font(.caption)
            .foregroundStyle(.white.opacity(0.7))
        }
        .padding(15)
        .background(cardColor)
        .clipShape(RoundedRectangle(cornerRadius: 17))
        .overlay {
            RoundedRectangle(cornerRadius: 17)
                .stroke(Color.white.opacity(0.07), lineWidth: 1)
        }
    }

    // MARK: Status Badge

    private func statusBadge(_ status: String) -> some View {
        let normalized = status.lowercased()

        let isPositive = [
            "accepted", "completed", "fulfilled"
        ].contains(normalized)

        let isCancelled = [
            "declined", "cancelled", "canceled"
        ].contains(normalized)

        let badgeColor = isPositive
            ? Color.green
            : (isCancelled ? Color.gray : gold)

        return Text(
            status.replacingOccurrences(of: "_", with: " ").capitalized
        )
        .font(.system(size: 10, weight: .bold))
        .foregroundStyle(badgeColor)
        .padding(.horizontal, 9)
        .padding(.vertical, 6)
        .background(badgeColor.opacity(0.12))
        .clipShape(Capsule())
    }

    // MARK: Date Formatting

    private func formatDate(_ value: String?) -> String {
        guard let value, !value.isEmpty else {
            return "Date not specified"
        }

        let isoFormatter = ISO8601DateFormatter()

        var date = isoFormatter.date(from: value)

        if date == nil {
            isoFormatter.formatOptions = [
                .withInternetDateTime,
                .withFractionalSeconds
            ]
            date = isoFormatter.date(from: value)
        }

        guard let date else {
            return "Date not specified"
        }

        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short

        return formatter.string(from: date)
    }

    // MARK: Load Supabase Activity

    @MainActor
    private func loadActivities() async {
        guard !isLoading else { return }

        isLoading = true
        errorMessage = nil

        defer {
            isLoading = false
        }

        guard let userID = SupabaseManager.client.auth.currentUser?.id else {
            errorMessage = "Please sign in to view your activity."
            return
        }

        if isDonor {
            await loadDonorActivity(userID: userID)
        } else {
            await loadRequesterActivity(userID: userID)
        }
    }

    // MARK: Donor Activity

    @MainActor
    private func loadDonorActivity(userID: UUID) async {
        do {
            let responses: [ActivityResponse] =
                try await SupabaseManager.client
                    .from("request_responses")
                    .select("id, request_id, donor_id, status")
                    .eq("donor_id", value: userID.uuidString)
                    .order("created_at", ascending: false)
                    .execute()
                    .value

            guard !responses.isEmpty else {
                activities = []
                return
            }

            let requestIDs = Array(
                Set(responses.map { $0.request_id.uuidString })
            )

            let requests: [BloodRequest] =
                try await SupabaseManager.client
                    .from("blood_requests")
                    .select()
                    .in("id", values: requestIDs)
                    .execute()
                    .value

            let requestLookup = Dictionary(
                uniqueKeysWithValues: requests.map { ($0.id, $0) }
            )

            activities = responses.compactMap { response in
                guard let request = requestLookup[response.request_id] else {
                    return nil
                }

                return BloodBridgeActivity(
                    id: response.id,
                    title: request.hospital_name,
                    subtitle: request.city,
                    bloodGroup: request.blood_group,
                    date: formatDate(request.needed_by),
                    status: response.status
                        .replacingOccurrences(of: "_", with: " ")
                        .capitalized,
                    units: request.units
                )
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    // MARK: Healthcare Requester Activity

    @MainActor
    private func loadRequesterActivity(userID: UUID) async {
        do {
            let requests: [BloodRequest] =
                try await SupabaseManager.client
                    .from("blood_requests")
                    .select()
                    .eq("requester_id", value: userID.uuidString)
                    .order("created_at", ascending: false)
                    .execute()
                    .value

            activities = requests.map { request in
                BloodBridgeActivity(
                    id: request.id,
                    title: request.hospital_name,
                    subtitle: request.city,
                    bloodGroup: request.blood_group,
                    date: formatDate(request.needed_by),
                    status: request.status
                        .replacingOccurrences(of: "_", with: " ")
                        .capitalized,
                    units: request.units
                )
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

// MARK: Preview

#Preview {
    NavigationStack {
        MyActivityView(role: .donor)
    }
}
