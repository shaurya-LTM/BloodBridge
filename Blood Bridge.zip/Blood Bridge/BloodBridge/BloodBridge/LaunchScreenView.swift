import SwiftUI

struct LaunchScreenView: View {
    @State private var showWelcome = false
    @State private var animateLogo = false

    private let backgroundColor = Color(
        red: 0.035,
        green: 0.035,
        blue: 0.045
    )

    private let bloodRed = Color(
        red: 0.88,
        green: 0.12,
        blue: 0.20
    )

    private let gold = Color(
        red: 0.80,
        green: 0.66,
        blue: 0.40
    )

    var body: some View {
        ZStack {
            if showWelcome {
                ContentView()
                    .transition(.opacity)
            } else {
                ZStack {
                    backgroundColor
                        .ignoresSafeArea()

                    VStack(spacing: 22) {
                        Spacer()

                        // Animated blood drop
                        ZStack {
                            Circle()
                                .fill(bloodRed.opacity(0.10))
                                .frame(width: 150, height: 150)
                                .scaleEffect(
                                    animateLogo ? 1.0 : 0.75
                                )

                            Circle()
                                .stroke(
                                    gold.opacity(0.45),
                                    lineWidth: 1
                                )
                                .frame(width: 122, height: 122)

                            Image(systemName: "drop.fill")
                                .font(.system(size: 66))
                                .foregroundStyle(bloodRed)
                                .shadow(
                                    color: bloodRed.opacity(0.65),
                                    radius: animateLogo ? 22 : 5
                                )
                                .scaleEffect(
                                    animateLogo ? 1.0 : 0.8
                                )
                        }

                        VStack(spacing: 9) {
                            Text("BloodBridge")
                                .font(
                                    .system(
                                        size: 35,
                                        weight: .bold,
                                        design: .rounded
                                    )
                                )
                                .tracking(1.5)
                                .foregroundStyle(.white)

                            Rectangle()
                                .fill(gold)
                                .frame(width: 58, height: 2)

                            Text("Every Drop Can Save a Life")
                                .font(.system(size: 15))
                                .tracking(1.1)
                                .foregroundStyle(
                                    Color.white.opacity(0.72)
                                )
                        }

                        Spacer()

                        ProgressView()
                            .tint(gold)
                            .padding(.bottom, 12)

                        Text("CONNECTING LIVES • SAVING LIVES")
                            .font(.system(size: 9, weight: .medium))
                            .tracking(2)
                            .foregroundStyle(gold.opacity(0.85))
                            .padding(.bottom, 35)
                    }
                    .padding(.horizontal, 24)
                }
                .transition(.opacity)
                .onAppear {
                    withAnimation(
                        .easeInOut(duration: 1.2)
                            .repeatForever(autoreverses: true)
                    ) {
                        animateLogo = true
                    }
                }
            }
        }
        .task {
            try? await Task.sleep(
                nanoseconds: 2_500_000_000
            )

            withAnimation(.easeInOut(duration: 0.5)) {
                showWelcome = true
            }
        }
    }
}

#Preview {
    LaunchScreenView()
}
