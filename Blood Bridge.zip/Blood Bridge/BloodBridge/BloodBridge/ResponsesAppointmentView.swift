import SwiftUI
import Supabase

// MARK: - Database Models

private struct BBResponseRow: Codable, Identifiable {
    let id: UUID
    let request_id: UUID
    let donor_id: UUID
    var status: String
    let created_at: Date?
    var completed_at: Date?
    var appointment_date: Date?
    var appointment_proposed_at: Date?
}

private struct BBRequestRow: Codable, Identifiable {
    let id: UUID
    let requester_id: UUID
    let blood_group: String
    let units: Int
    let hospital_name: String
    let city: String
    let urgency: String
    let needed_by: Date?
    let notes: String?
    let status: String
    let hospital_address: String?
    let contact_name: String?
    let contact_phone: String?
    let location_latitude: Double?
    let location_longitude: Double?
}

private struct BBProfileRow: Codable {
    let id: UUID
    let full_name: String
    let blood_group: String?
    let phone: String?
}

private struct BBResponseUpdate: Encodable {
    let status: String
    var appointment_date: Date? = nil
    var appointment_proposed_at: Date? = nil
    var completed_at: Date? = nil
}

private struct BBResponseDisplay: Identifiable {
    let id: UUID
    let requestID: UUID
    let donorID: UUID
    let personName: String
    let donorBloodGroup: String?
    let donorPhone: String?
    let hospitalName: String
    let location: String
    let bloodGroup: String
    let units: Int
    let urgency: String
    let neededBy: Date?
    let latitude: Double?
    let longitude: Double?
    var status: String
    var appointmentDate: Date?
    var completedAt: Date?
}

// MARK: - Responses and Appointments

struct ResponsesAppointmentsView: View {
    let role: ActivityRole

    @State private var selectedFilter = "All"
    @State private var records: [BBResponseDisplay] = []
    @State private var selectedAppointmentDate =
        Calendar.current.date(byAdding: .day, value: 2, to: Date()) ?? Date()

    @State private var isLoading = false
    @State private var busyID: UUID?
    @State private var loadError = ""
    @State private var showActionAlert = false
    @State private var alertTitle = ""
    @State private var alertMessage = ""

    private let backgroundColor = Color(
        red: 0.035, green: 0.035, blue: 0.045
    )
    private let cardColor = Color(
        red: 0.09, green: 0.09, blue: 0.11
    )
    private let bloodRed = Color(
        red: 0.88, green: 0.12, blue: 0.20
    )
    private let gold = Color(
        red: 0.80, green: 0.66, blue: 0.40
    )

    private var isDonor: Bool { role == .donor }
    private var pageTitle: String {
        isDonor ? "My Responses" : "Donor Responses"
    }

    private let filters = [
        "All", "Pending", "Accepted", "Appointment Proposed",
        "Appointment Confirmed", "Declined", "Completed"
    ]

    private var filteredRecords: [BBResponseDisplay] {
        guard selectedFilter != "All" else { return records }
        return records.filter { displayStatus($0.status) == selectedFilter }
    }

    private var activeCount: Int {
        records.filter {
            !["declined", "completed"].contains(normalizedStatus($0.status))
        }.count
    }

    var body: some View {
        ZStack {
            backgroundColor.ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    header
                    summaryCard

                    if !isDonor {
                        appointmentScheduler
                    }

                    filterSection

                    if !loadError.isEmpty {
                        errorPanel
                    }

                    if isLoading && records.isEmpty {
                        ProgressView("Loading responses…")
                            .tint(gold)
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .padding(32)
                    } else {
                        responseList
                    }

                    Button {
                        Task { await loadRecords() }
                    } label: {
                        Label("Refresh responses", systemImage: "arrow.clockwise")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(gold)
                            .frame(maxWidth: .infinity)
                    }
                    .padding(.top, 4)
                }
                .padding(20)
                .padding(.bottom, 30)
            }
            .refreshable {
                await loadRecords()
            }
        }
        .navigationTitle(pageTitle)
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(backgroundColor, for: .navigationBar)
        .toolbarBackground(.visible, for: .navigationBar)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .tint(gold)
        .task {
            await loadRecords()
        }
        .alert(alertTitle, isPresented: $showActionAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(alertMessage)
        }
    }

    // MARK: Header

    private var header: some View {
        VStack(alignment: .leading, spacing: 9) {
            Text("BLOODBRIDGE")
                .font(.system(size: 12, weight: .bold))
                .tracking(3)
                .foregroundStyle(gold)

            Text(pageTitle)
                .font(.system(size: 29, weight: .bold))
                .foregroundStyle(.white)

            Text(
                isDonor
                ? "Track your offers and appointment updates."
                : "Review donor offers and arrange appointments."
            )
            .font(.subheadline)
            .foregroundStyle(.white.opacity(0.65))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.top, 12)
    }

    // MARK: Summary

    private var summaryCard: some View {
        HStack(spacing: 14) {
            Image(systemName: "calendar.badge.clock")
                .font(.system(size: 26))
                .foregroundStyle(bloodRed)
                .frame(width: 56, height: 56)
                .background(bloodRed.opacity(0.13))
                .clipShape(RoundedRectangle(cornerRadius: 15))

            VStack(alignment: .leading, spacing: 5) {
                Text(isDonor ? "My Offers" : "Donor Responses")
                    .font(.subheadline)
                    .foregroundStyle(.white.opacity(0.7))

                Text("\(records.count)")
                    .font(.system(size: 28, weight: .bold))
                    .foregroundStyle(.white)
            }

            Spacer()

            VStack(alignment: .trailing, spacing: 5) {
                Text("Active")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.65))

                Text("\(activeCount)")
                    .font(.system(size: 22, weight: .bold))
                    .foregroundStyle(gold)
            }
        }
        .padding(16)
        .background(cardColor)
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }

    // MARK: Appointment Scheduler

    private var appointmentScheduler: some View {
        VStack(alignment: .leading, spacing: 13) {
            Text("Propose an Appointment")
                .font(.headline)
                .foregroundStyle(.white)

            Text("Choose a date, then propose it for an accepted donor offer.")
                .font(.caption)
                .foregroundStyle(.white.opacity(0.65))

            DatePicker(
                "Appointment Date",
                selection: $selectedAppointmentDate,
                in: Calendar.current.startOfDay(for: Date())...,
                displayedComponents: .date
            )
            .datePickerStyle(.compact)
            .tint(gold)
            .colorScheme(.dark)
            .padding(14)
            .background(cardColor)
            .clipShape(RoundedRectangle(cornerRadius: 14))
        }
    }

    // MARK: Filters

    private var filterSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Filter Responses")
                .font(.headline)
                .foregroundStyle(.white)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 9) {
                    ForEach(filters, id: \.self) { filter in
                        Button {
                            selectedFilter = filter
                        } label: {
                            Text(filter)
                                .font(.system(size: 12, weight: .semibold))
                                .foregroundStyle(
                                    selectedFilter == filter
                                    ? .white
                                    : .white.opacity(0.7)
                                )
                                .padding(.horizontal, 13)
                                .padding(.vertical, 10)
                                .background(
                                    selectedFilter == filter ? bloodRed : cardColor
                                )
                                .clipShape(Capsule())
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    }

    // MARK: Error Panel

    private var errorPanel: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("Could not load responses", systemImage: "exclamationmark.triangle.fill")
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.orange)

            Text(loadError)
                .font(.caption)
                .foregroundStyle(.white.opacity(0.8))

            Button("Try again") {
                Task { await loadRecords() }
            }
            .font(.subheadline.weight(.semibold))
            .foregroundStyle(gold)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(cardColor)
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    // MARK: Response List

    private var responseList: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Response Details")
                .font(.headline)
                .foregroundStyle(.white)

            if filteredRecords.isEmpty {
                VStack(spacing: 12) {
                    Image(systemName: "calendar.badge.clock")
                        .font(.system(size: 32))
                        .foregroundStyle(gold)

                    Text("No responses found")
                        .font(.headline)
                        .foregroundStyle(.white)

                    Text(
                        isDonor
                        ? "Your offers will appear here after you respond to a request."
                        : "Donor offers for your requests will appear here."
                    )
                    .font(.subheadline)
                    .foregroundStyle(.white.opacity(0.65))
                    .multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity)
                .padding(28)
                .background(cardColor)
                .clipShape(RoundedRectangle(cornerRadius: 18))
            } else {
                ForEach(filteredRecords) { record in
                    responseCard(record)
                }
            }
        }
    }

    // MARK: Response Card

    private func responseCard(_ record: BBResponseDisplay) -> some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack(alignment: .top, spacing: 12) {
                Image(systemName: isDonor ? "drop.fill" : "person.fill")
                    .font(.system(size: 22))
                    .foregroundStyle(bloodRed)
                    .frame(width: 52, height: 52)
                    .background(bloodRed.opacity(0.12))
                    .clipShape(RoundedRectangle(cornerRadius: 14))

                VStack(alignment: .leading, spacing: 5) {
                    Text(isDonor ? record.hospitalName : record.personName)
                        .font(.system(size: 15, weight: .bold))
                        .foregroundStyle(.white)

                    Text(isDonor ? "Your donation offer" : record.hospitalName)
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.65))

                    Label(record.location, systemImage: "mappin.and.ellipse")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.6))
                }

                Spacer(minLength: 0)
                statusBadge(displayStatus(record.status))
            }

            Divider().overlay(Color.white.opacity(0.08))

            HStack {
                Label(record.bloodGroup, systemImage: "drop.fill")
                    .foregroundStyle(bloodRed)

                Spacer()

                Text("\(record.units) unit\(record.units == 1 ? "" : "s")")
                    .foregroundStyle(.white.opacity(0.75))
            }
            .font(.subheadline.weight(.semibold))

            if !isDonor, let phone = record.donorPhone, !phone.isEmpty {
                Label(phone, systemImage: "phone.fill")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.75))
            }

            if let date = record.appointmentDate {
                Label(
                    date.formatted(date: .long, time: .omitted),
                    systemImage: "calendar"
                )
                .font(.caption)
                .foregroundStyle(gold)
            }

            if let completed = record.completedAt {
                Label(
                    "Completed \(completed.formatted(date: .abbreviated, time: .shortened))",
                    systemImage: "checkmark.seal.fill"
                )
                .font(.caption)
                .foregroundStyle(.green)
            }

            if record.status == "appointment_proposed" && isDonor {
                Text("The requester has proposed this appointment date.")
                    .font(.caption)
                    .foregroundStyle(gold)
            }

            if record.status == "appointment_confirmed" {
                Text("Appointment marked confirmed. Contact the hospital to verify arrangements.")
                    .font(.caption)
                    .foregroundStyle(.green)
            }

            actionButtons(for: record)
        }
        .padding(16)
        .background(cardColor)
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .overlay {
            RoundedRectangle(cornerRadius: 18)
                .stroke(Color.white.opacity(0.07), lineWidth: 1)
        }
    }

    // MARK: Actions

    @ViewBuilder
    private func actionButtons(for record: BBResponseDisplay) -> some View {
        if isDonor {
            if record.status == "appointment_proposed" {
                Button {
                    Task {
                        await changeStatus(
                            record,
                            newStatus: "appointment_confirmed",
                            successTitle: "Appointment Confirmed",
                            successMessage: "Your confirmation has been saved."
                        )
                    }
                } label: {
                    actionButtonLabel(
                        busyID == record.id ? "Saving…" : "Confirm Appointment",
                        symbol: "checkmark.circle.fill"
                    )
                }
                .disabled(busyID != nil)
                .buttonStyle(.plain)

            } else if record.status == "accepted" {
                Button {
                    showInfo(
                        title: "Offer Accepted",
                        message: "The requester accepted your offer. Coordinate with them and the hospital before travelling."
                    )
                } label: {
                    actionButtonLabel("View Status", symbol: "checkmark.circle")
                }
                .buttonStyle(.plain)

            } else if record.status == "appointment_confirmed" {
                Button {
                    Task {
                        await markCompleted(record)
                    }
                } label: {
                    actionButtonLabel("Mark Donation Completed", symbol: "checkmark.seal.fill")
                }
                .disabled(busyID != nil)
                .buttonStyle(.plain)
            }

        } else {
            if record.status == "pending" {
                HStack(spacing: 10) {
                    Button {
                        Task {
                            await changeStatus(
                                record,
                                newStatus: "accepted",
                                successTitle: "Offer Accepted",
                                successMessage: "The donor offer has been accepted."
                            )
                        }
                    } label: {
                        actionButtonLabel("Accept Offer", symbol: "checkmark")
                    }
                    .disabled(busyID != nil)
                    .buttonStyle(.plain)

                    Button {
                        Task {
                            await changeStatus(
                                record,
                                newStatus: "declined",
                                successTitle: "Offer Declined",
                                successMessage: "The donor offer has been declined."
                            )
                        }
                    } label: {
                        actionButtonLabel("Decline", symbol: "xmark", secondary: true)
                    }
                    .disabled(busyID != nil)
                    .buttonStyle(.plain)
                }

            } else if record.status == "accepted" {
                Button {
                    Task {
                        await proposeAppointment(for: record)
                    }
                } label: {
                    actionButtonLabel(
                        busyID == record.id ? "Saving…" : "Propose Appointment",
                        symbol: "calendar.badge.plus"
                    )
                }
                .disabled(busyID != nil)
                .buttonStyle(.plain)

            } else if record.status == "appointment_confirmed" {
                Button {
                    Task {
                        await markCompleted(record)
                    }
                } label: {
                    actionButtonLabel("Mark Donation Completed", symbol: "checkmark.seal.fill")
                }
                .disabled(busyID != nil)
                .buttonStyle(.plain)
            }
        }
    }

    private func actionButtonLabel(
        _ title: String,
        symbol: String,
        secondary: Bool = false
    ) -> some View {
        Label(title, systemImage: symbol)
            .font(.system(size: 12, weight: .semibold))
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 12)
            .background(secondary ? Color.gray.opacity(0.35) : bloodRed)
            .clipShape(RoundedRectangle(cornerRadius: 11))
    }

    // MARK: Load Supabase Data

    @MainActor
    private func loadRecords() async {
        guard let user = SupabaseManager.client.auth.currentUser else {
            loadError = "Please sign in to view your responses."
            records = []
            return
        }

        isLoading = true
        loadError = ""
        defer { isLoading = false }

        do {
            let client = SupabaseManager.client
            let responses: [BBResponseRow]

            if isDonor {
                responses = try await client
                    .from("request_responses")
                    .select()
                    .eq("donor_id", value: user.id)
                    .order("created_at", ascending: false)
                    .execute()
                    .value
            } else {
                let myRequests: [BBRequestRow] = try await client
                    .from("blood_requests")
                    .select()
                    .eq("requester_id", value: user.id)
                    .execute()
                    .value

                let requestIDs = myRequests.map(\.id)

                guard !requestIDs.isEmpty else {
                    records = []
                    return
                }

                responses = try await client
                    .from("request_responses")
                    .select()
                    .in("request_id", values: requestIDs)
                    .order("created_at", ascending: false)
                    .execute()
                    .value
            }

            var loaded: [BBResponseDisplay] = []

            for response in responses {
                let request: BBRequestRow

                do {
                    request = try await client
                        .from("blood_requests")
                        .select()
                        .eq("id", value: response.request_id)
                        .single()
                        .execute()
                        .value
                } catch {
                    // The request may have been removed or may no longer be visible.
                    continue
                }

                var profile: BBProfileRow?

                do {
                    profile = try await client
                        .from("profiles")
                        .select()
                        .eq("id", value: response.donor_id)
                        .single()
                        .execute()
                        .value
                } catch {
                    profile = nil
                }

                loaded.append(
                    BBResponseDisplay(
                        id: response.id,
                        requestID: response.request_id,
                        donorID: response.donor_id,
                        personName: profile?.full_name ?? "Blood donor",
                        donorBloodGroup: profile?.blood_group,
                        donorPhone: profile?.phone,
                        hospitalName: request.hospital_name,
                        location: request.city,
                        bloodGroup: request.blood_group,
                        units: request.units,
                        urgency: request.urgency,
                        neededBy: request.needed_by,
                        latitude: request.location_latitude,
                        longitude: request.location_longitude,
                        status: normalizedStatus(response.status),
                        appointmentDate: response.appointment_date,
                        completedAt: response.completed_at
                    )
                )
            }

            records = loaded
        } catch {
            loadError = error.localizedDescription
        }
    }

    // MARK: Update Status

    @MainActor
    private func changeStatus(
        _ record: BBResponseDisplay,
        newStatus: String,
        successTitle: String,
        successMessage: String
    ) async {
        guard busyID == nil else { return }
        guard let user = SupabaseManager.client.auth.currentUser else {
            showInfo(title: "Login Required", message: "Please sign in again.")
            return
        }

        // Only the requester may accept/decline or propose.
        // Only the donor may confirm a proposed appointment.
        if isDonor && user.id != record.donorID {
            showInfo(title: "Not Allowed", message: "This offer does not belong to your account.")
            return
        }

        busyID = record.id
        defer { busyID = nil }

        do {
            let update = BBResponseUpdate(
                status: newStatus,
                appointment_date: nil,
                appointment_proposed_at: nil,
                completed_at: nil
            )

            try await SupabaseManager.client
                .from("request_responses")
                .update(update)
                .eq("id", value: record.id)
                .execute()

            await loadRecords()
            showInfo(title: successTitle, message: successMessage)
        } catch {
            showInfo(title: "Update Failed", message: error.localizedDescription)
        }
    }

    // MARK: Propose Appointment

    @MainActor
    private func proposeAppointment(for record: BBResponseDisplay) async {
        guard !isDonor else { return }

        guard record.status == "accepted" else {
            showInfo(title: "Action Unavailable", message: "Only accepted offers can receive an appointment proposal.")
            return
        }

        guard selectedAppointmentDate >= Calendar.current.startOfDay(for: Date()) else {
            showInfo(title: "Invalid Date", message: "Choose today or a future date.")
            return
        }

        guard busyID == nil else { return }
        busyID = record.id
        defer { busyID = nil }

        do {
            let update = BBResponseUpdate(
                status: "appointment_proposed",
                appointment_date: selectedAppointmentDate,
                appointment_proposed_at: Date(),
                completed_at: nil
            )

            try await SupabaseManager.client
                .from("request_responses")
                .update(update)
                .eq("id", value: record.id)
                .execute()

            await loadRecords()
            showInfo(
                title: "Appointment Proposed",
                message: "The proposed date has been saved for the donor to review."
            )
        } catch {
            showInfo(title: "Could Not Propose Appointment", message: error.localizedDescription)
        }
    }

    // MARK: Complete Donation

    @MainActor
    private func markCompleted(_ record: BBResponseDisplay) async {
        guard busyID == nil else { return }
        busyID = record.id
        defer { busyID = nil }

        do {
            let update = BBResponseUpdate(
                status: "completed",
                appointment_date: nil,
                appointment_proposed_at: nil,
                completed_at: Date()
            )

            try await SupabaseManager.client
                .from("request_responses")
                .update(update)
                .eq("id", value: record.id)
                .execute()

            await loadRecords()
            showInfo(
                title: "Marked Completed",
                message: "The donation response has been marked completed. Only mark this after the donation has actually taken place."
            )
        } catch {
            showInfo(title: "Update Failed", message: error.localizedDescription)
        }
    }

    // MARK: Status Helpers

    private func normalizedStatus(_ status: String) -> String {
        status
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()
            .replacingOccurrences(of: " ", with: "_")
    }

    private func displayStatus(_ status: String) -> String {
        switch normalizedStatus(status) {
        case "pending": return "Pending"
        case "accepted": return "Accepted"
        case "declined": return "Declined"
        case "appointment_proposed": return "Appointment Proposed"
        case "appointment_confirmed": return "Appointment Confirmed"
        case "completed": return "Completed"
        default: return status.capitalized
        }
    }

    private func statusBadge(_ status: String) -> some View {
        let color: Color

        switch status {
        case "Accepted", "Appointment Confirmed", "Completed":
            color = .green
        case "Declined":
            color = .gray
        case "Appointment Proposed":
            color = gold
        default:
            color = .orange
        }

        return Text(status)
            .font(.system(size: 9, weight: .bold))
            .foregroundStyle(color)
            .padding(.horizontal, 9)
            .padding(.vertical, 7)
            .background(color.opacity(0.12))
            .clipShape(Capsule())
    }

    private func showInfo(title: String, message: String) {
        alertTitle = title
        alertMessage = message
        showActionAlert = true
    }
}

// MARK: - Previews

#Preview("Donor") {
    NavigationStack {
        ResponsesAppointmentsView(role: .donor)
    }
}

#Preview("Healthcare Requester") {
    NavigationStack {
        ResponsesAppointmentsView(role: .healthcareRequester)
    }
}
