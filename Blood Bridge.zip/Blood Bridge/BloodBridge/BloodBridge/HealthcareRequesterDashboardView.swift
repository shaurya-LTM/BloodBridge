import SwiftUI
import Supabase
import MapKit
import CoreLocation
import Combine
import UIKit

// MARK: - Location Manager

@MainActor
final class RequestLocationManager: NSObject, ObservableObject,
                                    CLLocationManagerDelegate {
    private let manager = CLLocationManager()

    @Published var location: CLLocation?
    @Published var authorizationStatus: CLAuthorizationStatus
    @Published var isLoading = false
    @Published var errorMessage = ""

    override init() {
        authorizationStatus = manager.authorizationStatus
        super.init()
        manager.delegate = self
    }

    func requestLocation() {
        errorMessage = ""

        switch manager.authorizationStatus {
        case .notDetermined:
            manager.requestWhenInUseAuthorization()

        case .authorizedAlways, .authorizedWhenInUse:
            isLoading = true
            manager.requestLocation()

        case .denied, .restricted:
            errorMessage =
                "Location access is disabled. Enable it in your iPhone Settings."

        @unknown default:
            errorMessage = "Unable to determine location permission."
        }
    }

    func locationManagerDidChangeAuthorization(
        _ manager: CLLocationManager
    ) {
        authorizationStatus = manager.authorizationStatus

        if manager.authorizationStatus == .authorizedAlways ||
           manager.authorizationStatus == .authorizedWhenInUse {
            isLoading = true
            manager.requestLocation()
        } else if manager.authorizationStatus == .denied ||
                    manager.authorizationStatus == .restricted {
            isLoading = false
            errorMessage =
                "Location access is disabled. Enable it in Settings."
        }
    }

    func locationManager(
        _ manager: CLLocationManager,
        didUpdateLocations locations: [CLLocation]
    ) {
        isLoading = false

        guard let latest = locations.last else {
            errorMessage = "No location was received. Please try again."
            return
        }

        guard latest.horizontalAccuracy >= 0,
              latest.horizontalAccuracy <= 1000 else {
            errorMessage =
                "Location accuracy is too low. Please try again outdoors."
            return
        }

        location = latest
        errorMessage = ""
    }

    func locationManager(
        _ manager: CLLocationManager,
        didFailWithError error: Error
    ) {
        isLoading = false
        errorMessage = "Could not get your location. Please try again."
    }
}

// MARK: - Request Screen

struct HealthcareRequesterDashboardView: View {
    @StateObject private var locationManager = RequestLocationManager()

    @State private var selectedBloodGroup = "O+"
    @State private var units = 1
    @State private var urgency = "Normal"
    @State private var requiredDate = Date()

    @State private var hospitalName = ""
    @State private var hospitalAddress = ""
    @State private var contactName = ""
    @State private var contactPhone = ""
    @State private var notes = ""

    @State private var isSubmitting = false
    @State private var alertTitle = ""
    @State private var alertMessage = ""
    @State private var showAlert = false

    private let bloodGroups = [
        "A+", "A-", "B+", "B-",
        "AB+", "AB-", "O+", "O-"
    ]

    private let urgencyOptions = [
        "Normal", "High", "Urgent"
    ]

    private let backgroundColor = Color(
        red: 0.035, green: 0.035, blue: 0.045
    )

    private let cardColor = Color(
        red: 0.09, green: 0.09, blue: 0.11
    )

    private let bloodRed = Color(
        red: 0.88, green: 0.12, blue: 0.20
    )

    private let gold = Color(
        red: 0.80, green: 0.66, blue: 0.40
    )

    // Save an approximate coordinate, not the raw GPS coordinate.
    private var approximateLatitude: Double? {
        guard let coordinate = locationManager.location?.coordinate else {
            return nil
        }
        return (coordinate.latitude * 1000).rounded() / 1000
    }

    private var approximateLongitude: Double? {
        guard let coordinate = locationManager.location?.coordinate else {
            return nil
        }
        return (coordinate.longitude * 1000).rounded() / 1000
    }

    private var approximateCoordinate: CLLocationCoordinate2D? {
        guard let latitude = approximateLatitude,
              let longitude = approximateLongitude else {
            return nil
        }

        return CLLocationCoordinate2D(
            latitude: latitude,
            longitude: longitude
        )
    }

    var body: some View {
        ZStack {
            backgroundColor.ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    header
                    formCard
                    submitButton

                    Text(
                        "Please verify all details before submitting. "
                        + "For a medical emergency, contact the hospital "
                        + "or local emergency services directly."
                    )
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.55))
                }
                .padding(20)
                .padding(.bottom, 24)
            }
        }
        .navigationTitle("Request Blood")
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(backgroundColor, for: .navigationBar)
        .toolbarBackground(.visible, for: .navigationBar)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .tint(gold)
        .alert(alertTitle, isPresented: $showAlert) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(alertMessage)
        }
    }

    // MARK: Header

    private var header: some View {
        VStack(alignment: .leading, spacing: 9) {
            Text("BLOODBRIDGE")
                .font(.system(size: 12, weight: .bold))
                .tracking(3)
                .foregroundStyle(gold)

            Text("Request Blood")
                .font(.system(size: 29, weight: .bold))
                .foregroundStyle(.white)

            Text(
                "Share the requirements so eligible donors "
                + "can respond to your request."
            )
            .font(.subheadline)
            .foregroundStyle(.white.opacity(0.65))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    // MARK: Main Form

    private var formCard: some View {
        VStack(alignment: .leading, spacing: 18) {
            sectionTitle("Blood Requirements")

            VStack(alignment: .leading, spacing: 8) {
                fieldLabel("Blood group")

                Picker("Blood group", selection: $selectedBloodGroup) {
                    ForEach(bloodGroups, id: \.self) { group in
                        Text(group).tag(group)
                    }
                }
                .pickerStyle(.menu)
                .tint(gold)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 12)
                .frame(height: 50)
                .background(backgroundColor)
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }

            VStack(alignment: .leading, spacing: 8) {
                fieldLabel("Number of units")

                Stepper(
                    "\(units) unit\(units == 1 ? "" : "s")",
                    value: $units,
                    in: 1...20
                )
                .foregroundStyle(.white)
                .padding(.horizontal, 12)
                .frame(height: 50)
                .background(backgroundColor)
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }

            VStack(alignment: .leading, spacing: 8) {
                fieldLabel("Urgency")

                Picker("Urgency", selection: $urgency) {
                    ForEach(urgencyOptions, id: \.self) { option in
                        Text(option).tag(option)
                    }
                }
                .pickerStyle(.segmented)
            }

            VStack(alignment: .leading, spacing: 8) {
                fieldLabel("Required by")

                DatePicker(
                    "Required by",
                    selection: $requiredDate,
                    in: Date()...,
                    displayedComponents: [.date, .hourAndMinute]
                )
                .labelsHidden()
                .tint(gold)
                .frame(maxWidth: .infinity, alignment: .leading)
            }

            Divider().overlay(.white.opacity(0.1))

            sectionTitle("Hospital Details")

            formField(
                "Hospital name",
                placeholder: "Enter hospital name",
                text: $hospitalName,
                icon: "cross.case"
            )

            formField(
                "Hospital address / city",
                placeholder: "Hospital address and city",
                text: $hospitalAddress,
                icon: "mappin.and.ellipse"
            )

            Divider().overlay(.white.opacity(0.1))

            locationSection

            Divider().overlay(.white.opacity(0.1))

            sectionTitle("Contact Details")

            formField(
                "Contact person",
                placeholder: "Full name",
                text: $contactName,
                icon: "person"
            )

            VStack(alignment: .leading, spacing: 8) {
                fieldLabel("Contact phone")

                HStack(spacing: 12) {
                    Image(systemName: "phone")
                        .foregroundStyle(gold)
                        .frame(width: 20)

                    TextField("10-digit mobile number", text: $contactPhone)
                        .keyboardType(.phonePad)
                        .textContentType(.telephoneNumber)
                }
                .padding(.horizontal, 14)
                .frame(height: 50)
                .background(backgroundColor)
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }

            VStack(alignment: .leading, spacing: 8) {
                fieldLabel("Additional notes (optional)")

                TextField(
                    "Any additional information",
                    text: $notes,
                    axis: .vertical
                )
                .lineLimit(3...5)
                .padding(14)
                .background(backgroundColor)
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }
        }
        .padding(18)
        .background(cardColor)
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .overlay {
            RoundedRectangle(cornerRadius: 20)
                .stroke(.white.opacity(0.07), lineWidth: 1)
        }
    }

    // MARK: Approximate Location

    private var locationSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            sectionTitle("Request Location")

            Text(
                "Share an approximate location so donors can find "
                + "the request area and nearby hospitals."
            )
            .font(.subheadline)
            .foregroundStyle(.white.opacity(0.65))

            Button {
                locationManager.requestLocation()
            } label: {
                HStack(spacing: 10) {
                    if locationManager.isLoading {
                        ProgressView().tint(.white)
                    } else {
                        Image(systemName: "location.fill")
                    }

                    Text(
                        locationManager.isLoading
                        ? "Getting Location..."
                        : "Use My Location"
                    )
                    .fontWeight(.semibold)
                }
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .frame(height: 48)
                .background(bloodRed.opacity(0.9))
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }
            .disabled(locationManager.isLoading)

            if let coordinate = approximateCoordinate {
                Map(
                    initialPosition: .region(
                        MKCoordinateRegion(
                            center: coordinate,
                            span: MKCoordinateSpan(
                                latitudeDelta: 0.025,
                                longitudeDelta: 0.025
                            )
                        )
                    )
                ) {
                    Marker(
                        "Approximate request area",
                        coordinate: coordinate
                    )
                    .tint(.red)
                }
                .frame(height: 210)
                .clipShape(RoundedRectangle(cornerRadius: 14))
                .overlay {
                    RoundedRectangle(cornerRadius: 14)
                        .stroke(.white.opacity(0.1), lineWidth: 1)
                }

                Label(
                    "Approximate location selected",
                    systemImage: "checkmark.circle.fill"
                )
                .font(.subheadline.weight(.medium))
                .foregroundStyle(.green)

                Text(
                    "Coordinates are rounded before saving. "
                    + "The map pin is approximate, not your exact GPS position."
                )
                .font(.caption)
                .foregroundStyle(.white.opacity(0.55))

            } else {
                Label(
                    "Location not selected",
                    systemImage: "mappin.slash"
                )
                .font(.subheadline)
                .foregroundStyle(.orange)
            }

            if !locationManager.errorMessage.isEmpty {
                Text(locationManager.errorMessage)
                    .font(.caption)
                    .foregroundStyle(.orange)

                if locationManager.authorizationStatus == .denied {
                    Button("Open App Settings") {
                        guard let url = URL(
                            string: UIApplication.openSettingsURLString
                        ) else { return }

                        UIApplication.shared.open(url)
                    }
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(gold)
                }
            }
        }
    }

    // MARK: Submit Button

    private var submitButton: some View {
        Button {
            Task {
                await submitBloodRequest()
            }
        } label: {
            HStack(spacing: 10) {
                if isSubmitting {
                    ProgressView().tint(.white)
                } else {
                    Image(systemName: "paperplane.fill")
                    Text("Submit Blood Request")
                }
            }
            .font(.system(size: 15, weight: .semibold))
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity)
            .frame(height: 54)
            .background(bloodRed)
            .clipShape(RoundedRectangle(cornerRadius: 14))
        }
        .disabled(isSubmitting)
        .opacity(isSubmitting ? 0.7 : 1)
    }

    // MARK: Reusable UI

    private func sectionTitle(_ title: String) -> some View {
        Text(title)
            .font(.system(size: 17, weight: .bold))
            .foregroundStyle(.white)
    }

    private func fieldLabel(_ title: String) -> some View {
        Text(title)
            .font(.system(size: 12, weight: .medium))
            .foregroundStyle(.white.opacity(0.7))
    }

    private func formField(
        _ title: String,
        placeholder: String,
        text: Binding<String>,
        icon: String
    ) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            fieldLabel(title)

            HStack(spacing: 12) {
                Image(systemName: icon)
                    .foregroundStyle(gold)
                    .frame(width: 20)

                TextField(placeholder, text: text)
                    .textInputAutocapitalization(.words)
                    .autocorrectionDisabled()
            }
            .padding(.horizontal, 14)
            .frame(height: 50)
            .background(backgroundColor)
            .clipShape(RoundedRectangle(cornerRadius: 12))
        }
    }

    // MARK: Supabase Submission

    @MainActor
    private func submitBloodRequest() async {
        guard let user = SupabaseManager.client.auth.currentUser else {
            presentAlert(
                "Login Required",
                "Please log in before creating a blood request."
            )
            return
        }

        let cleanHospital = hospitalName.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        let cleanAddress = hospitalAddress.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        let cleanContact = contactName.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        let cleanPhone = contactPhone.filter(\.isNumber)
        let cleanNotes = notes.trimmingCharacters(
            in: .whitespacesAndNewlines
        )

        guard !cleanHospital.isEmpty,
              !cleanAddress.isEmpty,
              !cleanContact.isEmpty else {
            presentAlert(
                "Missing Information",
                "Enter the hospital name, address, and contact person's name."
            )
            return
        }

        guard cleanPhone.count == 10 else {
            presentAlert(
                "Invalid Phone Number",
                "Enter a valid 10-digit mobile number."
            )
            return
        }

        guard requiredDate >= Date() else {
            presentAlert(
                "Invalid Date",
                "Choose a future date and time."
            )
            return
        }

        guard let latitude = approximateLatitude,
              let longitude = approximateLongitude else {
            presentAlert(
                "Location Required",
                "Tap Use My Location and wait for your approximate location before submitting."
            )
            return
        }

        isSubmitting = true
        defer { isSubmitting = false }

        do {
            let formatter = ISO8601DateFormatter()
            formatter.formatOptions = [
                .withInternetDateTime,
                .withFractionalSeconds
            ]

            let payload = NewBloodRequest(
                requester_id: user.id,
                blood_group: selectedBloodGroup,
                units: units,
                hospital_name: cleanHospital,
                hospital_address: cleanAddress,
                contact_name: cleanContact,
                contact_phone: cleanPhone,
                city: cleanAddress,
                urgency: urgency.lowercased(),
                needed_by: formatter.string(from: requiredDate),
                notes: cleanNotes.isEmpty ? nil : cleanNotes,
                status: "open",
                location_latitude: latitude,
                location_longitude: longitude
            )

            try await SupabaseManager.client
                .from("blood_requests")
                .insert(payload)
                .execute()

            presentAlert(
                "Request Submitted",
                "Your blood request and approximate location have been saved."
            )

            hospitalName = ""
            hospitalAddress = ""
            contactName = ""
            contactPhone = ""
            notes = ""
            units = 1
            urgency = "Normal"
            selectedBloodGroup = "O+"
            requiredDate = Date()

            // Keep the selected location available for another request.

        } catch {
            presentAlert(
                "Submission Failed",
                error.localizedDescription
            )
        }
    }

    @MainActor
    private func presentAlert(_ title: String, _ message: String) {
        alertTitle = title
        alertMessage = message
        showAlert = true
    }
}

// MARK: - Insert Payload

private struct NewBloodRequest: Encodable {
    let requester_id: UUID
    let blood_group: String
    let units: Int
    let hospital_name: String
    let hospital_address: String
    let contact_name: String
    let contact_phone: String
    let city: String
    let urgency: String
    let needed_by: String
    let notes: String?
    let status: String
    let location_latitude: Double
    let location_longitude: Double
}

#Preview {
    NavigationStack {
        HealthcareRequesterDashboardView()
    }
}
