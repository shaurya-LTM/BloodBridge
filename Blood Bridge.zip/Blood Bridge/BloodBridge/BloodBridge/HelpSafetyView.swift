//
//  HelpSafetyView.swift
//  BloodBridge
//
//  Created by KIET26 on 23/10/26.
//

import SwiftUI

struct HelpSafetyView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    HelpSafetyView()
}
