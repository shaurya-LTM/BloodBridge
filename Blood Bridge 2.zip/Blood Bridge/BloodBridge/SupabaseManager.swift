import Foundation
import Supabase

enum SupabaseManager {
    static let client = SupabaseClient(
        supabaseURL: URL(string: "https://wndynyioayqpbwuibcnz.supabase.co")!,
        supabaseKey: "sb_publishable_rsGSTCMLFPH2gijjcfgGKQ__6C3Sv2U"
    )
}
