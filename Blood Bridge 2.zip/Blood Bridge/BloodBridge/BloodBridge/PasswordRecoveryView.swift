import SwiftUI
import Supabase

struct PasswordRecoveryView: View {
    @Environment(\.dismiss) private var dismiss

    @State private var email: String
    @State private var isSending = false
    @State private var message = ""
    @State private var showAlert = false

    init(initialEmail: String = "") {
        _email = State(initialValue: initialEmail)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Email address", text: $email)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.emailAddress)
                        .autocorrectionDisabled()
                } header: {
                    Text("Account Email")
                }

                Section {
                    Button {
                        Task {
                            await sendRecoveryEmail()
                        }
                    } label: {
                        HStack {
                            Spacer()

                            if isSending {
                                ProgressView()
                            } else {
                                Text("Send Recovery Email")
                                    .fontWeight(.semibold)
                            }

                            Spacer()
                        }
                    }
                    .disabled(isSending)
                }
            }
            .navigationTitle("Reset Password")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
            .alert(
                "Password Recovery",
                isPresented: $showAlert
            ) {
                Button("OK") {
                    dismiss()
                }
            } message: {
                Text(message)
            }
        }
    }

    @MainActor
    private func sendRecoveryEmail() async {
        let cleanEmail = email.trimmingCharacters(
            in: .whitespacesAndNewlines
        )

        guard cleanEmail.contains("@"),
              cleanEmail.contains(".") else {
            message = "Enter a valid email address."
            showAlert = true
            return
        }

        isSending = true
        defer {
            isSending = false
        }

        do {
            try await SupabaseManager.client.auth
                .resetPasswordForEmail(cleanEmail)

            message = "Check your email for a password reset link."
            showAlert = true
        } catch {
            message = error.localizedDescription
            showAlert = true
        }
    }
}

#Preview {
    PasswordRecoveryView()
}
