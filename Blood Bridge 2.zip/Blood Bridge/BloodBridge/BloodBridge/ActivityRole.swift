import Foundation

enum ActivityRole: String, Codable, CaseIterable {
    case donor
    case healthcareRequester = "healthcare_requester"

    var displayName: String {
        switch self {
        case .donor:
            return "Blood Donor"

        case .healthcareRequester:
            return "Healthcare Requester"
        }
    }
}
