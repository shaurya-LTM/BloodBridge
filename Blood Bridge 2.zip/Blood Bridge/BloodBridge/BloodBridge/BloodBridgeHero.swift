import SwiftUI

struct BloodBridgeHero: View {
    let gold: Color

    var body: some View {
        GeometryReader { geometry in
            let width = geometry.size.width
            let height = geometry.size.height

            ZStack {
                Ellipse()
                    .fill(Color.red.opacity(0.09))
                    .frame(
                        width: width * 0.75,
                        height: height * 0.65
                    )
                    .blur(radius: 45)
                    .offset(
                        x: width * 0.1,
                        y: -height * 0.05
                    )

                Path { path in
                    path.move(
                        to: CGPoint(
                            x: 0,
                            y: height * 0.69
                        )
                    )

                    path.addLine(
                        to: CGPoint(
                            x: width * 0.18,
                            y: height * 0.53
                        )
                    )

                    path.addLine(
                        to: CGPoint(
                            x: width * 0.32,
                            y: height * 0.65
                        )
                    )

                    path.addLine(
                        to: CGPoint(
                            x: width * 0.50,
                            y: height * 0.48
                        )
                    )

                    path.addLine(
                        to: CGPoint(
                            x: width * 0.70,
                            y: height * 0.63
                        )
                    )

                    path.addLine(
                        to: CGPoint(
                            x: width,
                            y: height * 0.50
                        )
                    )

                    path.addLine(
                        to: CGPoint(
                            x: width,
                            y: height
                        )
                    )

                    path.addLine(
                        to: CGPoint(
                            x: 0,
                            y: height
                        )
                    )

                    path.closeSubpath()
                }
                .fill(
                    Color(
                        red: 0.07,
                        green: 0.055,
                        blue: 0.06
                    )
                )

                Path { path in
                    path.move(
                        to: CGPoint(
                            x: 0,
                            y: height * 0.76
                        )
                    )

                    path.addQuadCurve(
                        to: CGPoint(
                            x: width,
                            y: height * 0.76
                        ),
                        control: CGPoint(
                            x: width * 0.5,
                            y: height * 0.53
                        )
                    )
                }
                .stroke(
                    gold.opacity(0.95),
                    lineWidth: 2
                )
                .shadow(
                    color: gold.opacity(0.7),
                    radius: 8
                )

                Path { path in
                    path.move(
                        to: CGPoint(
                            x: width * 0.12,
                            y: height * 0.77
                        )
                    )

                    path.addQuadCurve(
                        to: CGPoint(
                            x: width * 0.88,
                            y: height * 0.77
                        ),
                        control: CGPoint(
                            x: width * 0.5,
                            y: height * 1.14
                        )
                    )
                }
                .stroke(
                    LinearGradient(
                        colors: [
                            gold.opacity(0.3),
                            gold,
                            gold.opacity(0.3)
                        ],
                        startPoint: .leading,
                        endPoint: .trailing
                    ),
                    lineWidth: 2.5
                )
                .shadow(
                    color: gold.opacity(0.45),
                    radius: 5
                )

                ForEach(0..<5, id: \.self) { index in
                    Capsule()
                        .fill(
                            index == 2
                            ? Color.red.opacity(0.65)
                            : gold.opacity(0.24)
                        )
                        .frame(
                            width: width * (
                                0.15 +
                                CGFloat(index % 3) * 0.08
                            ),
                            height: 1
                        )
                        .offset(
                            x: CGFloat(index - 2) * 17,
                            y: height * 0.84 +
                                CGFloat(index) * 8
                        )
                }

                BloodDropShape()
                    .fill(
                        LinearGradient(
                            colors: [
                                Color(
                                    red: 0.38,
                                    green: 0.015,
                                    blue: 0.025
                                ),
                                Color(
                                    red: 0.9,
                                    green: 0.035,
                                    blue: 0.045
                                ),
                                Color(
                                    red: 0.24,
                                    green: 0.005,
                                    blue: 0.015
                                )
                            ],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(
                        width: width * 0.34,
                        height: height * 0.65
                    )
                    .overlay {
                        BloodDropShape()
                            .stroke(
                                LinearGradient(
                                    colors: [
                                        Color.red,
                                        Color(
                                            red: 1,
                                            green: 0.45,
                                            blue: 0.35
                                        ),
                                        Color.red.opacity(0.6)
                                    ],
                                    startPoint: .top,
                                    endPoint: .bottom
                                ),
                                lineWidth: 2
                            )
                            .frame(
                                width: width * 0.34,
                                height: height * 0.65
                            )
                    }
                    .shadow(
                        color: .red.opacity(0.65),
                        radius: 18
                    )
                    .offset(y: -height * 0.12)

                VStack(spacing: 0) {
                    Image(systemName: "person.fill")
                        .font(.system(size: 35))

                    HStack(spacing: 2) {
                        Image(systemName: "person.fill")
                        Image(systemName: "person.fill")
                        Image(systemName: "person.fill")
                    }
                    .font(.system(size: 12))
                }
                .foregroundStyle(Color.red.opacity(0.8))
                .shadow(color: .red, radius: 8)
                .offset(y: -height * 0.13)

                Capsule()
                    .fill(Color.white.opacity(0.7))
                    .frame(
                        width: 3,
                        height: height * 0.18
                    )
                    .blur(radius: 1)
                    .rotationEffect(.degrees(22))
                    .offset(
                        x: -width * 0.095,
                        y: -height * 0.28
                    )
            }
            .frame(width: width, height: height)
            .clipped()
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(
            "A glowing red blood drop above a golden bridge at night"
        )
    }
}

struct BloodDropShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()

        path.move(
            to: CGPoint(
                x: rect.midX,
                y: rect.minY
            )
        )

        path.addCurve(
            to: CGPoint(
                x: rect.midX,
                y: rect.maxY
            ),
            control1: CGPoint(
                x: rect.maxX * 1.08,
                y: rect.height * 0.40
            ),
            control2: CGPoint(
                x: rect.maxX * 0.86,
                y: rect.height * 0.83
            )
        )

        path.addCurve(
            to: CGPoint(
                x: rect.midX,
                y: rect.minY
            ),
            control1: CGPoint(
                x: rect.minX + rect.width * 0.14,
                y: rect.height * 0.83
            ),
            control2: CGPoint(
                x: rect.minX - rect.width * 0.08,
                y: rect.height * 0.40
            )
        )

        path.closeSubpath()

        return path
    }
}
