import SwiftUI
import Supabase

// MARK: - Blood Request Model

struct BloodRequest: Identifiable, Decodable, Hashable {
    let id: UUID
    let requester_id: UUID
    let blood_group: String
    let units: Int
    let hospital_name: String
    let city: String
    let urgency: String
    let needed_by: String?
    let notes: String?
    let status: String
    let hospital_address: String?
    let contact_name: String?
    let contact_phone: String?

    var displayDate: String {
        guard let needed_by,
              !needed_by.isEmpty else {
            return "Date not specified"
        }

        let formatter = ISO8601DateFormatter()

        if let date = formatter.date(from: needed_by) {
            let output = DateFormatter()
            output.dateStyle = .medium
            output.timeStyle = .short
            return output.string(from: date)
        }

        formatter.formatOptions = [
            .withInternetDateTime,
            .withFractionalSeconds
        ]

        if let date = formatter.date(from: needed_by) {
            let output = DateFormatter()
            output.dateStyle = .medium
            output.timeStyle = .short
            return output.string(from: date)
        }

        return needed_by
    }

    var displayLocation: String {
        let address = hospital_address?
            .trimmingCharacters(
                in: .whitespacesAndNewlines
            ) ?? ""

        return address.isEmpty ? city : address
    }

    var displayNotes: String {
        let value = notes?
            .trimmingCharacters(
                in: .whitespacesAndNewlines
            ) ?? ""

        return value.isEmpty
            ? "No additional details provided."
            : value
    }

    var isUrgent: Bool {
        let value = urgency.lowercased()

        return value == "urgent"
            || value == "high"
    }
}

// MARK: - Donation Response Payload

private struct NewDonationResponse: Encodable {
    let request_id: UUID
    let donor_id: UUID
    let status: String
}

// MARK: - Donor Dashboard

struct DonorDashboardView: View {
    @State private var requests: [BloodRequest] = []
    @State private var selectedBloodGroup = "All"
    @State private var searchText = ""

    @State private var isLoading = false
    @State private var alertTitle = ""
    @State private var alertMessage = ""
    @State private var showingAlert = false

    private let bloodGroups = [
        "All",
        "A+",
        "A-",
        "B+",
        "B-",
        "AB+",
        "AB-",
        "O+",
        "O-"
    ]

    private var filteredRequests: [BloodRequest] {
        requests.filter { request in
            let matchesBloodGroup =
                selectedBloodGroup == "All"
                || request.blood_group.caseInsensitiveCompare(
                    selectedBloodGroup
                ) == .orderedSame

            let query = searchText.trimmingCharacters(
                in: .whitespacesAndNewlines
            )

            let matchesSearch =
                query.isEmpty
                || request.hospital_name
                    .localizedCaseInsensitiveContains(query)
                || request.city
                    .localizedCaseInsensitiveContains(query)
                || request.displayLocation
                    .localizedCaseInsensitiveContains(query)
                || request.blood_group
                    .localizedCaseInsensitiveContains(query)

            return matchesBloodGroup && matchesSearch
        }
    }

    var body: some View {
        ZStack {
            BloodBridgeStyle.background
                .ignoresSafeArea()

            VStack(spacing: 18) {
                header
                donorActions
                searchBar
                bloodGroupFilters

                if isLoading && requests.isEmpty {
                    loadingState
                } else if filteredRequests.isEmpty {
                    emptyState
                } else {
                    requestList
                }
            }
            .padding(.top, 12)
        }
        .navigationTitle("Find Blood Requests")
        .navigationBarTitleDisplayMode(.inline)
        .toolbarColorScheme(
            .dark,
            for: .navigationBar
        )
        .toolbarBackground(
            BloodBridgeStyle.background,
            for: .navigationBar
        )
        .toolbarBackground(
            .visible,
            for: .navigationBar
        )
        .task {
            await loadRequests()
        }
        .refreshable {
            await loadRequests()
        }
        .alert(
            alertTitle,
            isPresented: $showingAlert
        ) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(alertMessage)
        }
    }

    // MARK: - Header

    private var header: some View {
        VStack(
            alignment: .leading,
            spacing: 8
        ) {
            HStack(spacing: 10) {
                Image(systemName: "drop.fill")
                    .font(
                        .system(
                            size: 27,
                            weight: .bold
                        )
                    )
                    .foregroundStyle(
                        BloodBridgeStyle.red
                    )

                Text("BloodBridge")
                    .font(
                        .system(
                            size: 27,
                            weight: .bold
                        )
                    )
                    .foregroundStyle(.white)
            }

            Text("Every donation can save a life.")
                .font(.subheadline)
                .foregroundStyle(
                    BloodBridgeStyle.muted
                )

            HStack(spacing: 8) {
                Image(systemName: "heart.fill")
                    .foregroundStyle(
                        BloodBridgeStyle.red
                    )

                Text(
                    "\(filteredRequests.count) matching requests"
                )
                .font(
                    .subheadline.weight(
                        .medium
                    )
                )
                .foregroundStyle(
                    BloodBridgeStyle.gold
                )

                Spacer()

                Button {
                    Task {
                        await loadRequests()
                    }
                } label: {
                    Image(
                        systemName: "arrow.clockwise"
                    )
                    .foregroundStyle(
                        BloodBridgeStyle.gold
                    )
                }
                .disabled(isLoading)
                .accessibilityLabel(
                    "Refresh requests"
                )
            }
            .padding(.top, 4)
        }
        .frame(
            maxWidth: .infinity,
            alignment: .leading
        )
        .padding(.horizontal, 20)
    }

    // MARK: - Donor Actions

    private var donorActions: some View {
        VStack(spacing: 10) {
            NavigationLink {
                RewardsView()
            } label: {
                actionRow(
                    icon: "trophy.fill",
                    title: "Donor Rewards",
                    subtitle: "View your points, level, and impact",
                    color: BloodBridgeStyle.gold
                )
            }
            .buttonStyle(.plain)

            NavigationLink {
                ResponsesAppointmentsView(
                    role: .donor
                )
            } label: {
                actionRow(
                    icon: "calendar.badge.clock",
                    title: "My Responses",
                    subtitle: "Track offers and appointment updates",
                    color: BloodBridgeStyle.red
                )
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 20)
    }

    private func actionRow(
        icon: String,
        title: String,
        subtitle: String,
        color: Color
    ) -> some View {
        HStack(spacing: 13) {
            Image(systemName: icon)
                .font(.title3)
                .foregroundStyle(color)
                .frame(
                    width: 38,
                    height: 38
                )
                .background(color.opacity(0.12))
                .clipShape(Circle())

            VStack(
                alignment: .leading,
                spacing: 4
            ) {
                Text(title)
                    .font(
                        .subheadline.weight(
                            .semibold
                        )
                    )
                    .foregroundStyle(.white)

                Text(subtitle)
                    .font(.caption)
                    .foregroundStyle(
                        .white.opacity(0.62)
                    )
            }

            Spacer()

            Image(systemName: "chevron.right")
                .font(
                    .caption.weight(
                        .semibold
                    )
                )
                .foregroundStyle(
                    .white.opacity(0.5)
                )
        }
        .padding(15)
        .background(
            BloodBridgeStyle.card
        )
        .clipShape(
            RoundedRectangle(cornerRadius: 16)
        )
        .overlay {
            RoundedRectangle(cornerRadius: 16)
                .stroke(
                    color.opacity(0.22),
                    lineWidth: 1
                )
        }
    }

    // MARK: - Search

    private var searchBar: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass")
                .foregroundStyle(
                    BloodBridgeStyle.muted
                )

            TextField(
                "Search hospital or city",
                text: $searchText
            )
            .foregroundStyle(.white)
            .tint(BloodBridgeStyle.gold)
            .autocorrectionDisabled()
        }
        .padding(14)
        .background(
            BloodBridgeStyle.card
        )
        .clipShape(
            RoundedRectangle(cornerRadius: 14)
        )
        .overlay {
            RoundedRectangle(cornerRadius: 14)
                .stroke(
                    .white.opacity(0.08),
                    lineWidth: 1
                )
        }
        .padding(.horizontal, 20)
    }

    // MARK: - Blood Group Filters

    private var bloodGroupFilters: some View {
        ScrollView(
            .horizontal,
            showsIndicators: false
        ) {
            HStack(spacing: 9) {
                ForEach(
                    bloodGroups,
                    id: \.self
                ) { group in
                    let isSelected =
                        selectedBloodGroup == group

                    Button {
                        selectedBloodGroup = group
                    } label: {
                        Text(group)
                            .font(
                                .subheadline.weight(
                                    .semibold
                                )
                            )
                            .foregroundStyle(
                                isSelected
                                ? BloodBridgeStyle.background
                                : .white
                            )
                            .padding(.horizontal, 15)
                            .padding(.vertical, 9)
                            .background(
                                isSelected
                                ? BloodBridgeStyle.gold
                                : BloodBridgeStyle.card
                            )
                            .clipShape(Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 20)
        }
    }

    // MARK: - Loading State

    private var loadingState: some View {
        VStack {
            Spacer()

            ProgressView(
                "Finding blood requests..."
            )
            .tint(BloodBridgeStyle.gold)
            .foregroundStyle(.white)

            Spacer()
        }
        .frame(
            maxWidth: .infinity,
            maxHeight: .infinity
        )
    }

    // MARK: - Request List

    private var requestList: some View {
        ScrollView {
            LazyVStack(spacing: 14) {
                ForEach(filteredRequests) { request in
                    NavigationLink {
                        BloodRequestDetailView(
                            request: request
                        )
                    } label: {
                        requestCard(request)
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 2)
            .padding(.bottom, 24)
        }
    }

    private func requestCard(
        _ request: BloodRequest
    ) -> some View {
        VStack(
            alignment: .leading,
            spacing: 13
        ) {
            HStack(
                alignment: .top,
                spacing: 12
            ) {
                ZStack {
                    RoundedRectangle(
                        cornerRadius: 13
                    )
                    .fill(
                        BloodBridgeStyle.red
                            .opacity(0.15)
                    )
                    .frame(
                        width: 58,
                        height: 58
                    )

                    Text(request.blood_group)
                        .font(
                            .system(
                                size: 17,
                                weight: .bold
                            )
                        )
                        .foregroundStyle(
                            BloodBridgeStyle.red
                        )
                }

                VStack(
                    alignment: .leading,
                    spacing: 5
                ) {
                    Text(request.hospital_name)
                        .font(.headline)
                        .foregroundStyle(.white)
                        .multilineTextAlignment(
                            .leading
                        )

                    Label(
                        request.city,
                        systemImage: "mappin.and.ellipse"
                    )
                    .font(.subheadline)
                    .foregroundStyle(
                        BloodBridgeStyle.muted
                    )
                    .lineLimit(2)
                }

                Spacer(minLength: 4)

                if request.isUrgent {
                    Text(
                        request.urgency.uppercased()
                    )
                    .font(
                        .system(
                            size: 9,
                            weight: .bold
                        )
                    )
                    .foregroundStyle(
                        BloodBridgeStyle.red
                    )
                    .padding(.horizontal, 8)
                    .padding(.vertical, 6)
                    .background(
                        BloodBridgeStyle.red
                            .opacity(0.12)
                    )
                    .clipShape(Capsule())
                }
            }

            Divider()
                .overlay(
                    .white.opacity(0.08)
                )

            HStack(spacing: 16) {
                Label(
                    "\(request.units) unit\(request.units == 1 ? "" : "s")",
                    systemImage: "drop"
                )

                Spacer()

                Image(systemName: "calendar")
                    .foregroundStyle(
                        BloodBridgeStyle.gold
                    )

                Text(request.displayDate)
                    .lineLimit(2)
                    .multilineTextAlignment(
                        .trailing
                    )
            }
            .font(.caption)
            .foregroundStyle(
                BloodBridgeStyle.muted
            )

            HStack {
                Text("View request")
                    .font(
                        .subheadline.weight(
                            .semibold
                        )
                    )
                    .foregroundStyle(
                        BloodBridgeStyle.gold
                    )

                Spacer()

                Image(systemName: "arrow.up.right")
                    .foregroundStyle(
                        BloodBridgeStyle.gold
                    )
            }
        }
        .padding(16)
        .background(
            BloodBridgeStyle.card
        )
        .clipShape(
            RoundedRectangle(cornerRadius: 18)
        )
        .overlay {
            RoundedRectangle(cornerRadius: 18)
                .stroke(
                    .white.opacity(0.07),
                    lineWidth: 1
                )
        }
    }

    // MARK: - Empty State

    private var emptyState: some View {
        VStack(spacing: 14) {
            Spacer()

            Image(
                systemName: "heart.text.clipboard"
            )
            .font(.system(size: 48))
            .foregroundStyle(
                BloodBridgeStyle.gold
            )

            Text(
                isLoading
                ? "Loading requests..."
                : "No matching requests"
            )
            .font(.title3.bold())
            .foregroundStyle(.white)

            Text(
                isLoading
                ? "Please wait while requests are loaded."
                : "Try another blood group or search term. Pull down to refresh."
            )
            .font(.subheadline)
            .foregroundStyle(
                BloodBridgeStyle.muted
            )
            .multilineTextAlignment(.center)

            if !isLoading {
                Button("Refresh") {
                    Task {
                        await loadRequests()
                    }
                }
                .font(
                    .subheadline.weight(
                        .semibold
                    )
                )
                .foregroundStyle(
                    BloodBridgeStyle.gold
                )
            }

            Spacer()
        }
        .padding(30)
        .frame(
            maxWidth: .infinity,
            maxHeight: .infinity
        )
    }

    // MARK: - Fetch Requests

    @MainActor
    private func loadRequests() async {
        guard !isLoading else {
            return
        }

        isLoading = true

        defer {
            isLoading = false
        }

        do {
            let result: [BloodRequest] =
                try await SupabaseManager.client
                    .from("blood_requests")
                    .select()
                    .eq(
                        "status",
                        value: "open"
                    )
                    .order(
                        "created_at",
                        ascending: false
                    )
                    .execute()
                    .value

            requests = result
        } catch {
            alertTitle = "Couldn't load requests"

            alertMessage = """
            Blood requests could not be loaded from Supabase.

            \(error.localizedDescription)
            """

            showingAlert = true
        }
    }
}

// MARK: - Request Details

struct BloodRequestDetailView: View {
    let request: BloodRequest

    @State private var isSubmitting = false
    @State private var alertTitle = ""
    @State private var alertMessage = ""
    @State private var showingAlert = false

    var body: some View {
        ZStack {
            BloodBridgeStyle.background
                .ignoresSafeArea()

            ScrollView {
                VStack(
                    alignment: .leading,
                    spacing: 20
                ) {
                    requestHeader

                    VStack(
                        alignment: .leading,
                        spacing: 17
                    ) {
                        detailRow(
                            icon: "cross.case.fill",
                            title: "Hospital",
                            value: request.hospital_name
                        )

                        detailRow(
                            icon: "mappin.and.ellipse",
                            title: "Location",
                            value: request.displayLocation
                        )

                        detailRow(
                            icon: "drop.fill",
                            title: "Blood group",
                            value: request.blood_group
                        )

                        detailRow(
                            icon: "cross.vial.fill",
                            title: "Units required",
                            value: "\(request.units)"
                        )

                        detailRow(
                            icon: "exclamationmark.triangle.fill",
                            title: "Urgency",
                            value: request.urgency.capitalized
                        )

                        detailRow(
                            icon: "calendar",
                            title: "Needed by",
                            value: request.displayDate
                        )

                        detailRow(
                            icon: "text.alignleft",
                            title: "Additional details",
                            value: request.displayNotes
                        )
                    }
                    .padding(18)
                    .background(
                        BloodBridgeStyle.card
                    )
                    .clipShape(
                        RoundedRectangle(cornerRadius: 18)
                    )

                    Button {
                        Task {
                            await offerToDonate()
                        }
                    } label: {
                        HStack(spacing: 10) {
                            if isSubmitting {
                                ProgressView()
                                    .tint(.white)
                            } else {
                                Image(
                                    systemName: "heart.fill"
                                )
                            }

                            Text(
                                isSubmitting
                                ? "Submitting offer..."
                                : "Offer to Donate"
                            )
                            .fontWeight(.bold)
                        }
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(
                            BloodBridgeStyle.red
                        )
                        .clipShape(
                            RoundedRectangle(cornerRadius: 14)
                        )
                    }
                    .disabled(
                        isSubmitting
                        || request.status
                            .lowercased() != "open"
                    )

                    Text(
                        "Your offer will be recorded in BloodBridge. Confirm medical eligibility and arrangements with the hospital before donating."
                    )
                    .font(.caption)
                    .foregroundStyle(
                        BloodBridgeStyle.muted
                    )
                    .multilineTextAlignment(.center)
                }
                .padding(20)
            }
        }
        .navigationTitle("Request Details")
        .navigationBarTitleDisplayMode(.inline)
        .toolbarColorScheme(
            .dark,
            for: .navigationBar
        )
        .toolbarBackground(
            BloodBridgeStyle.background,
            for: .navigationBar
        )
        .toolbarBackground(
            .visible,
            for: .navigationBar
        )
        .alert(
            alertTitle,
            isPresented: $showingAlert
        ) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(alertMessage)
        }
    }

    private var requestHeader: some View {
        VStack(spacing: 12) {
            Image(systemName: "drop.fill")
                .font(.system(size: 42))
                .foregroundStyle(
                    BloodBridgeStyle.red
                )

            Text(request.blood_group)
                .font(
                    .system(
                        size: 34,
                        weight: .heavy
                    )
                )
                .foregroundStyle(
                    BloodBridgeStyle.gold
                )

            Text(request.hospital_name)
                .font(.title3.bold())
                .foregroundStyle(.white)
                .multilineTextAlignment(.center)

            Text(
                "\(request.units) unit\(request.units == 1 ? "" : "s") needed"
            )
            .font(.subheadline)
            .foregroundStyle(
                BloodBridgeStyle.muted
            )

            if request.isUrgent {
                Text("URGENT REQUEST")
                    .font(.caption.bold())
                    .foregroundStyle(
                        BloodBridgeStyle.red
                    )
                    .padding(.horizontal, 12)
                    .padding(.vertical, 7)
                    .background(
                        BloodBridgeStyle.red
                            .opacity(0.12)
                    )
                    .clipShape(Capsule())
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 10)
    }

    private func detailRow(
        icon: String,
        title: String,
        value: String
    ) -> some View {
        HStack(
            alignment: .top,
            spacing: 12
        ) {
            Image(systemName: icon)
                .font(.system(size: 17))
                .foregroundStyle(
                    BloodBridgeStyle.gold
                )
                .frame(width: 24)

            VStack(
                alignment: .leading,
                spacing: 5
            ) {
                Text(title)
                    .font(.caption)
                    .foregroundStyle(
                        BloodBridgeStyle.muted
                    )

                Text(value)
                    .font(.subheadline)
                    .foregroundStyle(.white)
                    .textSelection(.enabled)
            }

            Spacer(minLength: 0)
        }
    }

    // MARK: - Submit Donation Offer

    @MainActor
    private func offerToDonate() async {
        guard !isSubmitting else {
            return
        }

        guard let donorID =
            SupabaseManager.client.auth.currentUser?.id else {
            alertTitle = "Sign in required"
            alertMessage =
                "Please sign in to respond to a blood request."
            showingAlert = true
            return
        }

        guard donorID != request.requester_id else {
            alertTitle = "Not allowed"
            alertMessage =
                "You cannot offer to donate to your own request."
            showingAlert = true
            return
        }

        guard request.status.lowercased() == "open" else {
            alertTitle = "Request unavailable"
            alertMessage =
                "This blood request is no longer open."
            showingAlert = true
            return
        }

        isSubmitting = true

        defer {
            isSubmitting = false
        }

        do {
            let existingResponses: [ExistingDonationResponse] =
                try await SupabaseManager.client
                    .from("request_responses")
                    .select("id, status")
                    .eq(
                        "request_id",
                        value: request.id.uuidString
                    )
                    .eq(
                        "donor_id",
                        value: donorID.uuidString
                    )
                    .limit(1)
                    .execute()
                    .value

            if let existingResponse =
                existingResponses.first {
                alertTitle = "Offer Already Submitted"

                alertMessage = """
                You have already responded to this blood request.

                Current status: \(existingResponse.status.capitalized)
                """

                showingAlert = true
                return
            }

            let payload = NewDonationResponse(
                request_id: request.id,
                donor_id: donorID,
                status: "pending"
            )

            try await SupabaseManager.client
                .from("request_responses")
                .insert(payload)
                .execute()

            alertTitle = "Offer submitted"

            alertMessage = """
            Your donation offer has been recorded.

            The requester can now review your response. You will earn reward points after the donation is completed.
            """

            showingAlert = true
        } catch {
            alertTitle = "Couldn't submit offer"

            alertMessage = """
            Your donation offer could not be submitted.

            \(error.localizedDescription)

            If you already submitted an offer, open My Responses to check its status.
            """

            showingAlert = true
        }
    }
}

// MARK: - Existing Response Model

private struct ExistingDonationResponse: Decodable {
    let id: UUID
    let status: String
}

// MARK: - Preview

#Preview {
    NavigationStack {
        DonorDashboardView()
    }
}
