import SwiftUI
import Supabase
import UIKit

struct ProfileSettingsView: View {
    let isDonor: Bool

    @State private var fullName = ""
    @State private var email = ""
    @State private var phone = ""
    @State private var newPassword = ""
    @State private var confirmPassword = ""

    @AppStorage("notificationsEnabled")
    private var notificationsEnabled = true

    @AppStorage("emailNotificationsEnabled")
    private var emailNotificationsEnabled = true

    @State private var isLoadingProfile = true
    @State private var isSavingProfile = false
    @State private var isChangingPassword = false

    @State private var alertTitle = "Profile"
    @State private var alertMessage = ""
    @State private var showAlert = false

    @State private var showHelpAlert = false
    @State private var showPrivacyAlert = false

    private let backgroundColor = Color(
        red: 0.035,
        green: 0.035,
        blue: 0.045
    )

    private let cardColor = Color(
        red: 0.09,
        green: 0.09,
        blue: 0.11
    )

    private let bloodRed = Color(
        red: 0.88,
        green: 0.12,
        blue: 0.20
    )

    private let gold = Color(
        red: 0.80,
        green: 0.66,
        blue: 0.40
    )

    private var roleName: String {
        isDonor ? "Blood Donor" : "Healthcare Requester"
    }

    var body: some View {
        ZStack {
            backgroundColor
                .ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    pageHeader
                    profileCard
                    editProfileSection
                    passwordSection
                    notificationSection
                    privacySection
                    supportSection
                    footer
                }
                .padding(20)
                .padding(.bottom, 30)
            }
        }
        .navigationTitle("Profile & Settings")
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(backgroundColor, for: .navigationBar)
        .toolbarBackground(.visible, for: .navigationBar)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .tint(gold)
        .task {
            await loadProfile()
        }
        .alert(alertTitle, isPresented: $showAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(alertMessage)
        }
        .alert("Help & Support", isPresented: $showHelpAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(
                "Support contact details will be added when the BloodBridge support service is configured."
            )
        }
        .alert("Privacy & Location", isPresented: $showPrivacyAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(
                "BloodBridge may use your location to find nearby hospitals. You can manage location access in your iPhone Settings."
            )
        }
    }

    // MARK: - Profile Loading

    @MainActor
    private func loadProfile() async {
        isLoadingProfile = true
        defer {
            isLoadingProfile = false
        }

        do {
            let client = SupabaseManager.client
            let user = try await client.auth.user()

            email = user.email ?? ""

            if let savedName = user.userMetadata["full_name"]?.stringValue {
                fullName = savedName
            }

            let profiles: [ProfileRecord] = try await client
                .from("profiles")
                .select(
                    "full_name, phone, notifications_enabled, email_notifications_enabled"
                )
                .eq("id", value: user.id.uuidString)
                .limit(1)
                .execute()
                .value

            if let profile = profiles.first {
                if let name = profile.fullName, !name.isEmpty {
                    fullName = name
                }

                phone = profile.phone ?? ""

                notificationsEnabled =
                    profile.notificationsEnabled ?? true

                emailNotificationsEnabled =
                    profile.emailNotificationsEnabled ?? true
            }
        } catch {
            showMessage(
                "Couldn't load your profile",
                error.localizedDescription
            )
        }
    }

    // MARK: - Header

    private var pageHeader: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("BLOODBRIDGE")
                .font(.system(size: 12, weight: .bold))
                .tracking(3)
                .foregroundStyle(gold)

            Text("Your Account")
                .font(.system(size: 29, weight: .bold))
                .foregroundStyle(.white)

            Text("Manage your profile and preferences.")
                .font(.subheadline)
                .foregroundStyle(.white.opacity(0.65))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.top, 12)
    }

    // MARK: - Profile Card

    private var profileCard: some View {
        VStack(spacing: 15) {
            ZStack {
                Circle()
                    .fill(bloodRed.opacity(0.15))
                    .frame(width: 88, height: 88)

                Image(systemName: "person.fill")
                    .font(.system(size: 37))
                    .foregroundStyle(bloodRed)
            }

            VStack(spacing: 5) {
                Text(fullName.isEmpty ? "Your Name" : fullName)
                    .font(.system(size: 21, weight: .bold))
                    .foregroundStyle(.white)

                Text(
                    email.isEmpty
                    ? "Add your email address"
                    : email
                )
                .font(.subheadline)
                .foregroundStyle(.white.opacity(0.65))
                .multilineTextAlignment(.center)

                Text(roleName)
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(gold)
                    .padding(.horizontal, 13)
                    .padding(.vertical, 7)
                    .background(gold.opacity(0.12))
                    .clipShape(Capsule())
                    .padding(.top, 5)

                if isLoadingProfile {
                    ProgressView()
                        .tint(gold)
                        .padding(.top, 4)
                }
            }
        }
        .frame(maxWidth: .infinity)
        .padding(22)
        .background(cardColor)
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .overlay {
            RoundedRectangle(cornerRadius: 20)
                .stroke(Color.white.opacity(0.07), lineWidth: 1)
        }
    }

    // MARK: - Edit Profile

    private var editProfileSection: some View {
        VStack(alignment: .leading, spacing: 15) {
            sectionTitle("Personal Information")

            VStack(alignment: .leading, spacing: 14) {
                profileField(
                    title: "Full Name",
                    placeholder: "Enter your full name",
                    text: $fullName,
                    icon: "person"
                )

                profileField(
                    title: "Email Address",
                    placeholder: "Enter your email",
                    text: $email,
                    icon: "envelope",
                    keyboard: .emailAddress
                )

                profileField(
                    title: "Phone Number",
                    placeholder: "10-digit mobile number",
                    text: $phone,
                    icon: "phone",
                    keyboard: .phonePad
                )

                Button {
                    Task {
                        await saveProfile()
                    }
                } label: {
                    HStack {
                        if isSavingProfile {
                            ProgressView()
                                .tint(.white)
                        } else {
                            Image(systemName: "checkmark.circle.fill")
                        }

                        Text(
                            isSavingProfile
                            ? "Saving..."
                            : "Save Changes"
                        )
                    }
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 15)
                    .background(bloodRed)
                    .clipShape(RoundedRectangle(cornerRadius: 13))
                }
                .buttonStyle(.plain)
                .disabled(isSavingProfile || isLoadingProfile)
            }
            .padding(17)
            .background(cardColor)
            .clipShape(RoundedRectangle(cornerRadius: 18))
        }
    }

    private func profileField(
        title: String,
        placeholder: String,
        text: Binding<String>,
        icon: String,
        keyboard: UIKeyboardType = .default
    ) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.subheadline.weight(.medium))
                .foregroundStyle(.white.opacity(0.85))

            HStack(spacing: 11) {
                Image(systemName: icon)
                    .foregroundStyle(gold)
                    .frame(width: 20)

                TextField(placeholder, text: text)
                    .font(.body)
                    .foregroundStyle(.white)
                    .keyboardType(keyboard)
                    .textInputAutocapitalization(
                        keyboard == .emailAddress
                        ? .never
                        : .words
                    )
                    .autocorrectionDisabled(
                        keyboard == .emailAddress
                    )
            }
            .padding(13)
            .background(backgroundColor)
            .clipShape(RoundedRectangle(cornerRadius: 11))
            .overlay {
                RoundedRectangle(cornerRadius: 11)
                    .stroke(
                        Color.white.opacity(0.08),
                        lineWidth: 1
                    )
            }
        }
    }

    // MARK: - Save Profile

    @MainActor
    private func saveProfile() async {
        let name = fullName.trimmingCharacters(
            in: .whitespacesAndNewlines
        )

        let newEmail = email.trimmingCharacters(
            in: .whitespacesAndNewlines
        )

        let mobile = phone.filter(\.isNumber)

        guard !name.isEmpty else {
            showMessage(
                "Invalid name",
                "Please enter your full name."
            )
            return
        }

        guard newEmail.contains("@"),
              newEmail.contains(".") else {
            showMessage(
                "Invalid email",
                "Please enter a valid email address."
            )
            return
        }

        guard mobile.count == 10 else {
            showMessage(
                "Invalid phone",
                "Enter a 10-digit mobile number."
            )
            return
        }

        isSavingProfile = true
        defer {
            isSavingProfile = false
        }

        do {
            let client = SupabaseManager.client
            let user = try await client.auth.user()
            let userID = user.id.uuidString

            try await client.auth.update(
                user: UserAttributes(
                    data: [
                        "full_name": .string(name)
                    ]
                )
            )

            try await client
                .from("profiles")
                .upsert(
                    ProfileUpsert(
                        id: userID,
                        fullName: name,
                        phone: mobile,
                        notificationsEnabled: notificationsEnabled,
                        emailNotificationsEnabled: emailNotificationsEnabled
                    ),
                    onConflict: "id"
                )
                .execute()

            if newEmail.lowercased() !=
                (user.email ?? "").lowercased() {
                try await client.auth.update(
                    user: UserAttributes(email: newEmail)
                )

                showMessage(
                    "Profile saved",
                    "Your name and phone were saved. Supabase may require you to confirm the email change before the new email becomes active."
                )
            } else {
                showMessage(
                    "Profile saved",
                    "Your name, phone number, and notification preferences were successfully saved."
                )
            }

            fullName = name
            phone = mobile
            email = newEmail
        } catch {
            showMessage(
                "Couldn't save profile",
                error.localizedDescription
            )
        }
    }

    // MARK: - Password

    private var passwordSection: some View {
        VStack(alignment: .leading, spacing: 15) {
            sectionTitle("Change Password")

            VStack(alignment: .leading, spacing: 14) {
                SecureField(
                    "New password (at least 8 characters)",
                    text: $newPassword
                )
                .textContentType(.newPassword)
                .padding(13)
                .background(backgroundColor)
                .clipShape(RoundedRectangle(cornerRadius: 11))
                .foregroundStyle(.white)

                SecureField(
                    "Confirm new password",
                    text: $confirmPassword
                )
                .textContentType(.newPassword)
                .padding(13)
                .background(backgroundColor)
                .clipShape(RoundedRectangle(cornerRadius: 11))
                .foregroundStyle(.white)

                Button {
                    Task {
                        await changePassword()
                    }
                } label: {
                    HStack {
                        if isChangingPassword {
                            ProgressView()
                                .tint(.white)
                        } else {
                            Image(systemName: "lock.fill")
                        }

                        Text(
                            isChangingPassword
                            ? "Updating..."
                            : "Update Password"
                        )
                    }
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 15)
                    .background(gold.opacity(0.85))
                    .clipShape(RoundedRectangle(cornerRadius: 13))
                }
                .buttonStyle(.plain)
                .disabled(isChangingPassword)
            }
            .padding(17)
            .background(cardColor)
            .clipShape(RoundedRectangle(cornerRadius: 18))
        }
    }

    @MainActor
    private func changePassword() async {
        guard newPassword.count >= 8 else {
            showMessage(
                "Invalid password",
                "Use at least 8 characters."
            )
            return
        }

        guard newPassword == confirmPassword else {
            showMessage(
                "Passwords don't match",
                "Please enter the same password in both fields."
            )
            return
        }

        isChangingPassword = true
        defer {
            isChangingPassword = false
        }

        do {
            try await SupabaseManager.client.auth.update(
                user: UserAttributes(password: newPassword)
            )

            newPassword = ""
            confirmPassword = ""

            showMessage(
                "Password updated",
                "Your password was successfully updated."
            )
        } catch {
            showMessage(
                "Password update failed",
                error.localizedDescription
            )
        }
    }

    // MARK: - Notifications

    private var notificationSection: some View {
        VStack(alignment: .leading, spacing: 15) {
            sectionTitle("Notifications")

            VStack(spacing: 0) {
                settingsToggle(
                    icon: "bell.badge",
                    title: "Push Notifications",
                    subtitle: "Donation and request updates",
                    isOn: $notificationsEnabled
                )

                Divider()
                    .overlay(Color.white.opacity(0.08))

                settingsToggle(
                    icon: "envelope",
                    title: "Email Notifications",
                    subtitle: "Updates sent by email",
                    isOn: $emailNotificationsEnabled
                )
            }
            .padding(.horizontal, 15)
            .background(cardColor)
            .clipShape(RoundedRectangle(cornerRadius: 18))
        }
    }

    private func settingsToggle(
        icon: String,
        title: String,
        subtitle: String,
        isOn: Binding<Bool>
    ) -> some View {
        HStack(spacing: 13) {
            Image(systemName: icon)
                .font(.title3)
                .foregroundStyle(gold)
                .frame(width: 28)

            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(.white)

                Text(subtitle)
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.6))
            }

            Spacer()

            Toggle(title, isOn: isOn)
                .labelsHidden()
                .tint(bloodRed)
        }
        .padding(.vertical, 15)
    }

    // MARK: - Privacy

    private var privacySection: some View {
        VStack(alignment: .leading, spacing: 15) {
            sectionTitle("Privacy & Security")

            settingsButton(
                icon: "hand.raised.fill",
                title: "Privacy & Location",
                subtitle: "Learn about location permissions",
                showChevron: true
            ) {
                showPrivacyAlert = true
            }
        }
    }

    // MARK: - Support

    private var supportSection: some View {
        VStack(alignment: .leading, spacing: 15) {
            sectionTitle("Support")

            settingsButton(
                icon: "questionmark.circle.fill",
                title: "Help & Support",
                subtitle: "Get help using BloodBridge",
                showChevron: true
            ) {
                showHelpAlert = true
            }
        }
    }

    private func settingsButton(
        icon: String,
        title: String,
        subtitle: String,
        showChevron: Bool,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            HStack(spacing: 13) {
                Image(systemName: icon)
                    .font(.title3)
                    .foregroundStyle(gold)
                    .frame(width: 28)

                VStack(alignment: .leading, spacing: 4) {
                    Text(title)
                        .font(.subheadline.weight(.medium))
                        .foregroundStyle(.white)

                    Text(subtitle)
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.6))
                }

                Spacer()

                if showChevron {
                    Image(systemName: "chevron.right")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.white.opacity(0.5))
                }
            }
            .padding(16)
            .background(cardColor)
            .clipShape(RoundedRectangle(cornerRadius: 15))
        }
        .buttonStyle(.plain)
    }

    // MARK: - Helpers

    private func sectionTitle(_ title: String) -> some View {
        Text(title)
            .font(.system(size: 18, weight: .bold))
            .foregroundStyle(.white)
    }

    @MainActor
    private func showMessage(
        _ title: String,
        _ message: String
    ) {
        alertTitle = title
        alertMessage = message
        showAlert = true
    }

    private var footer: some View {
        VStack(spacing: 6) {
            Image(systemName: "drop.fill")
                .font(.title2)
                .foregroundStyle(bloodRed)

            Text("BloodBridge")
                .font(.headline)
                .foregroundStyle(.white)

            Text("Every Drop Can Save a Life")
                .font(.caption)
                .foregroundStyle(gold)

            Text("Demo Version")
                .font(.caption2)
                .foregroundStyle(.white.opacity(0.4))
                .padding(.top, 4)
        }
        .frame(maxWidth: .infinity)
        .padding(.top, 8)
    }
}

// MARK: - Supabase Models

private struct ProfileRecord: Decodable {
    let fullName: String?
    let phone: String?
    let notificationsEnabled: Bool?
    let emailNotificationsEnabled: Bool?

    enum CodingKeys: String, CodingKey {
        case fullName = "full_name"
        case phone
        case notificationsEnabled = "notifications_enabled"
        case emailNotificationsEnabled = "email_notifications_enabled"
    }
}

private struct ProfileUpsert: Encodable {
    let id: String
    let fullName: String
    let phone: String
    let notificationsEnabled: Bool
    let emailNotificationsEnabled: Bool

    enum CodingKeys: String, CodingKey {
        case id
        case fullName = "full_name"
        case phone
        case notificationsEnabled = "notifications_enabled"
        case emailNotificationsEnabled = "email_notifications_enabled"
    }
}

#Preview {
    NavigationStack {
        ProfileSettingsView(isDonor: true)
    }
}
