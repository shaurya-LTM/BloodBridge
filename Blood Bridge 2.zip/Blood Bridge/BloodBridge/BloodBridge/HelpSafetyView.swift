import SwiftUI

struct HelpSafetyView: View {
    private let background = BloodBridgeStyle.background
    private let card = BloodBridgeStyle.card
    private let gold = BloodBridgeStyle.gold
    private let red = BloodBridgeStyle.red

    var body: some View {
        ZStack {
            background
                .ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    header

                    safetyCard(
                        icon: "cross.case.fill",
                        title: "Medical Emergencies",
                        text: "BloodBridge is not an emergency service. Call your local emergency number or contact the hospital directly if someone is in immediate danger."
                    )

                    safetyCard(
                        icon: "checkmark.shield.fill",
                        title: "Before Donating",
                        text: "Only donate if you are medically eligible. Follow the instructions of the hospital or licensed medical professionals."
                    )

                    safetyCard(
                        icon: "person.2.fill",
                        title: "Meet Safely",
                        text: "Coordinate donations through the hospital or healthcare requester. Avoid sharing unnecessary personal information."
                    )

                    safetyCard(
                        icon: "lock.shield.fill",
                        title: "Privacy",
                        text: "BloodBridge stores approximate request locations. Do not share private medical information in public notes."
                    )

                    VStack(alignment: .leading, spacing: 12) {
                        Text("Report a Problem")
                            .font(.headline)
                            .foregroundStyle(.white)

                        Text(
                            "If you see suspicious activity, false information, or unsafe behavior, stop communicating and contact the hospital or BloodBridge administrator."
                        )
                        .font(.subheadline)
                        .foregroundStyle(.white.opacity(0.7))
                    }
                    .padding(18)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(card)
                    .clipShape(RoundedRectangle(cornerRadius: 17))
                }
                .padding(20)
                .padding(.bottom, 30)
            }
        }
        .navigationTitle("Help & Safety")
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(background, for: .navigationBar)
        .toolbarBackground(.visible, for: .navigationBar)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .tint(gold)
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("BLOODBRIDGE")
                .font(.system(size: 12, weight: .bold))
                .tracking(3)
                .foregroundStyle(gold)

            Text("Help & Safety")
                .font(.system(size: 30, weight: .bold))
                .foregroundStyle(.white)

            Text("Important guidance for donors and healthcare requesters.")
                .font(.subheadline)
                .foregroundStyle(.white.opacity(0.65))
        }
        .padding(.top, 12)
    }

    private func safetyCard(
        icon: String,
        title: String,
        text: String
    ) -> some View {
        HStack(alignment: .top, spacing: 14) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundStyle(red)
                .frame(width: 34)

            VStack(alignment: .leading, spacing: 7) {
                Text(title)
                    .font(.headline)
                    .foregroundStyle(.white)

                Text(text)
                    .font(.subheadline)
                    .foregroundStyle(.white.opacity(0.68))
                    .fixedSize(horizontal: false, vertical: true)
            }

            Spacer(minLength: 0)
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(card)
        .clipShape(RoundedRectangle(cornerRadius: 17))
    }
}

#Preview {
    NavigationStack {
        HelpSafetyView()
    }
}
