import SwiftUI
import Supabase

struct AuthSessionView: View {
    @State private var isLoading = true
    @State private var isAuthenticated = false

    var body: some View {
        Group {
            if isLoading {
                ZStack {
                    BloodBridgeStyle.background
                        .ignoresSafeArea()

                    ProgressView("Loading...")
                        .tint(BloodBridgeStyle.gold)
                        .foregroundStyle(.white)
                }
            } else if isAuthenticated {
                NavigationStack {
                    HomeDashboardView {
                        isAuthenticated = false
                    }
                    .navigationBarBackButtonHidden(true)
                }
            } else {
                ContentView {
                    isAuthenticated = true
                }
            }
        }
        .preferredColorScheme(.dark)
        .task {
            await loadSession()
        }
    }

    @MainActor
    private func loadSession() async {
        isAuthenticated =
            SupabaseManager.client.auth.currentUser != nil

        isLoading = false
    }
}

#Preview {
    AuthSessionView()
}
