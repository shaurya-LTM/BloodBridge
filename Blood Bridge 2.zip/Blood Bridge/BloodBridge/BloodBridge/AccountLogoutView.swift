import SwiftUI
import Supabase

struct AccountLogoutView: View {
    let role: ActivityRole

    // The parent should use this callback to return to the login screen.
    var onSignedOut: () -> Void = {}

    @State private var showLogoutConfirmation = false
    @State private var isSigningOut = false
    @State private var errorMessage = ""
    @State private var showErrorAlert = false

    private let red = Color(red: 0.88, green: 0.12, blue: 0.20)
    private let gold = Color(red: 0.80, green: 0.66, blue: 0.40)
    private let card = Color(red: 0.09, green: 0.09, blue: 0.11)
    private let background = Color(red: 0.035, green: 0.035, blue: 0.045)

    private var roleTitle: String {
        role == .donor ? "Blood Donor" : "Healthcare Requester"
    }

    var body: some View {
        ZStack {
            background.ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("BLOODBRIDGE")
                            .font(.system(size: 12, weight: .bold))
                            .tracking(3)
                            .foregroundStyle(gold)

                        Text("Account")
                            .font(.system(size: 30, weight: .bold))
                            .foregroundStyle(.white)

                        Text("Account options and app information.")
                            .font(.subheadline)
                            .foregroundStyle(.white.opacity(0.65))
                    }
                    .padding(.top, 12)

                    VStack(spacing: 13) {
                        Image(systemName: "person.crop.circle.fill")
                            .font(.system(size: 66))
                            .foregroundStyle(red)

                        Text("BloodBridge User")
                            .font(.title3.bold())
                            .foregroundStyle(.white)

                        Text(roleTitle)
                            .font(.subheadline)
                            .foregroundStyle(gold)

                        Text("Authenticated account")
                            .font(.caption)
                            .foregroundStyle(.white.opacity(0.55))
                    }
                    .frame(maxWidth: .infinity)
                    .padding(22)
                    .background(card)
                    .clipShape(RoundedRectangle(cornerRadius: 18))

                    VStack(alignment: .leading, spacing: 12) {
                        Text("Account Options")
                            .font(.headline)
                            .foregroundStyle(.white)

                        NavigationLink {
                            ProfileSettingsView(isDonor: role == .donor)
                        } label: {
                            accountRow(
                                "Profile & Settings",
                                subtitle: "Edit your profile and preferences",
                                symbol: "person.crop.circle"
                            )
                        }
                        .buttonStyle(.plain)

                        NavigationLink {
                            HelpSafetyView()
                        } label: {
                            accountRow(
                                "Help & Safety",
                                subtitle: "Read safety and privacy guidance",
                                symbol: "shield.lefthalf.filled"
                            )
                        }
                        .buttonStyle(.plain)
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        Text("Sign Out")
                            .font(.headline)
                            .foregroundStyle(.white)

                        Text("Sign out of your BloodBridge account on this device.")
                            .font(.subheadline)
                            .foregroundStyle(.white.opacity(0.65))

                        Button {
                            showLogoutConfirmation = true
                        } label: {
                            HStack(spacing: 10) {
                                if isSigningOut {
                                    ProgressView()
                                        .tint(.white)
                                } else {
                                    Image(
                                        systemName:
                                            "rectangle.portrait.and.arrow.right"
                                    )
                                }

                                Text(isSigningOut ? "Signing Out..." : "Sign Out")
                            }
                            .font(.headline)
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 15)
                            .background(red)
                            .clipShape(RoundedRectangle(cornerRadius: 13))
                        }
                        .buttonStyle(.plain)
                        .disabled(isSigningOut)
                    }
                    .padding(17)
                    .background(card)
                    .clipShape(RoundedRectangle(cornerRadius: 17))

                    Text("BloodBridge · Demo Version")
                        .font(.caption2)
                        .foregroundStyle(.white.opacity(0.4))
                        .frame(maxWidth: .infinity)
                }
                .padding(20)
                .padding(.bottom, 30)
            }
        }
        .navigationTitle("Account")
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(background, for: .navigationBar)
        .toolbarBackground(.visible, for: .navigationBar)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .tint(gold)
        .confirmationDialog(
            "Sign out of BloodBridge?",
            isPresented: $showLogoutConfirmation,
            titleVisibility: .visible
        ) {
            Button("Sign Out", role: .destructive) {
                Task {
                    await signOut()
                }
            }

            Button("Cancel", role: .cancel) { }
        } message: {
            Text("You will need to sign in again to access your account.")
        }
        .alert("Could Not Sign Out", isPresented: $showErrorAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(errorMessage)
        }
    }

    // MARK: - Supabase Sign Out

    @MainActor
    private func signOut() async {
        guard !isSigningOut else { return }

        isSigningOut = true
        defer { isSigningOut = false }

        do {
            try await SupabaseManager.client.auth.signOut()

            // The parent must reset the app's authenticated root screen.
            onSignedOut()
        } catch {
            errorMessage = error.localizedDescription
            showErrorAlert = true
        }
    }

    // MARK: - Account Row

    private func accountRow(
        _ title: String,
        subtitle: String,
        symbol: String
    ) -> some View {
        HStack(spacing: 13) {
            Image(systemName: symbol)
                .font(.title3)
                .foregroundStyle(gold)
                .frame(width: 30)

            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.white)

                Text(subtitle)
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.6))
            }

            Spacer()

            Image(systemName: "chevron.right")
                .font(.caption.weight(.semibold))
                .foregroundStyle(.white.opacity(0.5))
        }
        .padding(15)
        .background(card)
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }
}

#Preview {
    NavigationStack {
        AccountLogoutView(role: .donor)
    }
}
