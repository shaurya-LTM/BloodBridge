import SwiftUI
import Speech
import AVFoundation
import Combine

struct VoiceRequestView: View {
    @Environment(\.dismiss) private var dismiss

    @Binding var hospitalName: String
    @Binding var hospitalAddress: String
    @Binding var contactName: String
    @Binding var contactPhone: String
    @Binding var notes: String
    @Binding var selectedBloodGroup: String
    @Binding var units: Int
    @Binding var urgency: String

    @StateObject private var speechManager =
        VoiceRequestSpeechManager()

    @State private var transcript = ""
    @State private var errorMessage = ""
    @State private var showError = false

    private let background = BloodBridgeStyle.background
    private let card = BloodBridgeStyle.card
    private let gold = BloodBridgeStyle.gold
    private let red = BloodBridgeStyle.red

    private let bloodGroups = [
        "A+",
        "A-",
        "B+",
        "B-",
        "AB+",
        "AB-",
        "O+",
        "O-"
    ]

    private let urgencyOptions = [
        "Normal",
        "High",
        "Urgent"
    ]

    var body: some View {
        NavigationStack {
            ZStack {
                background
                    .ignoresSafeArea()

                ScrollView {
                    VStack(
                        alignment: .leading,
                        spacing: 20
                    ) {
                        header
                        instructions
                        transcriptCard
                        applyButton
                    }
                    .padding(20)
                    .padding(.bottom, 30)
                }
            }
            .navigationTitle("Voice Request")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(
                background,
                for: .navigationBar
            )
            .toolbarBackground(
                .visible,
                for: .navigationBar
            )
            .toolbarColorScheme(
                .dark,
                for: .navigationBar
            )
            .tint(gold)
            .alert(
                "Voice Request",
                isPresented: $showError
            ) {
                Button("OK", role: .cancel) { }
            } message: {
                Text(errorMessage)
            }
            .onDisappear {
                speechManager.stopRecording()
            }
        }
    }

    // MARK: - Header

    private var header: some View {
        VStack(
            alignment: .leading,
            spacing: 8
        ) {
            Text("BLOODBRIDGE")
                .font(.system(size: 12, weight: .bold))
                .tracking(3)
                .foregroundStyle(gold)

            Text("Speak Your Request")
                .font(.system(size: 29, weight: .bold))
                .foregroundStyle(.white)

            Text(
                "Describe the blood requirement naturally. You can review everything before applying it."
            )
            .font(.subheadline)
            .foregroundStyle(.white.opacity(0.65))
        }
        .padding(.top, 12)
    }

    // MARK: - Instructions

    private var instructions: some View {
        VStack(
            alignment: .leading,
            spacing: 10
        ) {
            Text("Example")
                .font(.headline)
                .foregroundStyle(.white)

            Text(
                "I need two units of O positive blood at City Hospital in Delhi. The request is urgent. Contact Rahul at 9876543210."
            )
            .font(.subheadline)
            .foregroundStyle(.white.opacity(0.7))
            .fixedSize(
                horizontal: false,
                vertical: true
            )
        }
        .padding(16)
        .frame(
            maxWidth: .infinity,
            alignment: .leading
        )
        .background(card)
        .clipShape(
            RoundedRectangle(cornerRadius: 16)
        )
    }

    // MARK: - Transcript Card

    private var transcriptCard: some View {
        VStack(
            alignment: .leading,
            spacing: 14
        ) {
            HStack {
                Text("Voice Transcript")
                    .font(.headline)
                    .foregroundStyle(.white)

                Spacer()

                if speechManager.isRecording {
                    Circle()
                        .fill(.red)
                        .frame(width: 10, height: 10)
                        .overlay {
                            Circle()
                                .stroke(
                                    .red.opacity(0.35),
                                    lineWidth: 7
                                )
                        }
                }
            }

            Text(
                transcript.isEmpty
                ? "Tap the microphone and describe your request."
                : transcript
            )
            .font(.body)
            .foregroundStyle(
                transcript.isEmpty
                ? .white.opacity(0.45)
                : .white
            )
            .frame(
                maxWidth: .infinity,
                minHeight: 150,
                alignment: .topLeading
            )
            .padding(14)
            .background(background)
            .clipShape(
                RoundedRectangle(cornerRadius: 13)
            )

            Button {
                toggleRecording()
            } label: {
                HStack(spacing: 10) {
                    Image(
                        systemName: speechManager.isRecording
                        ? "stop.fill"
                        : "mic.fill"
                    )

                    Text(
                        speechManager.isRecording
                        ? "Stop Recording"
                        : "Start Recording"
                    )
                    .fontWeight(.semibold)
                }
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 15)
                .background(
                    speechManager.isRecording
                    ? Color.gray
                    : red
                )
                .clipShape(
                    RoundedRectangle(cornerRadius: 13)
                )
            }
        }
        .padding(17)
        .background(card)
        .clipShape(
            RoundedRectangle(cornerRadius: 18)
        )
    }

    // MARK: - Apply Button

    private var applyButton: some View {
        Button {
            applyTranscriptToRequest()
        } label: {
            HStack {
                Spacer()

                Image(systemName: "checkmark.circle.fill")

                Text("Apply to Request Form")
                    .fontWeight(.semibold)

                Spacer()
            }
            .foregroundStyle(.black)
            .padding(.vertical, 15)
            .background(gold)
            .clipShape(
                RoundedRectangle(cornerRadius: 13)
            )
        }
        .disabled(
            transcript
                .trimmingCharacters(
                    in: .whitespacesAndNewlines
                )
                .isEmpty
        )
        .opacity(
            transcript
                .trimmingCharacters(
                    in: .whitespacesAndNewlines
                )
                .isEmpty
            ? 0.5
            : 1
        )
    }

    // MARK: - Recording

    private func toggleRecording() {
        if speechManager.isRecording {
            speechManager.stopRecording()
            transcript = speechManager.transcript
            return
        }

        speechManager.startRecording(
            onTranscript: { newTranscript in
                transcript = newTranscript
            },
            onError: { message in
                errorMessage = message
                showError = true
            }
        )
    }

    // MARK: - Apply Transcript

    private func applyTranscriptToRequest() {
        let cleanTranscript = transcript.trimmingCharacters(
            in: .whitespacesAndNewlines
        )

        guard !cleanTranscript.isEmpty else {
            return
        }

        notes = cleanTranscript

        let lowercased = cleanTranscript.lowercased()

        // Blood-group recognition.
        let spokenBloodGroups: [String: String] = [
            "a positive": "A+",
            "a negative": "A-",
            "b positive": "B+",
            "b negative": "B-",
            "ab positive": "AB+",
            "ab negative": "AB-",
            "o positive": "O+",
            "o negative": "O-",
            "a+": "A+",
            "a-": "A-",
            "b+": "B+",
            "b-": "B-",
            "ab+": "AB+",
            "ab-": "AB-",
            "o+": "O+",
            "o-": "O-"
        ]

        for (
            spokenValue,
            bloodGroup
        ) in spokenBloodGroups {
            if lowercased.contains(spokenValue) {
                selectedBloodGroup = bloodGroup
                break
            }
        }

        // Urgency recognition.
        for option in urgencyOptions {
            if lowercased.contains(
                option.lowercased()
            ) {
                urgency = option
                break
            }
        }

        // Numeric and word-based unit recognition.
        let numberWords: [String: Int] = [
            "one": 1,
            "two": 2,
            "three": 3,
            "four": 4,
            "five": 5,
            "six": 6,
            "seven": 7,
            "eight": 8,
            "nine": 9,
            "ten": 10
        ]

        if let matchedNumber = numberWords.first(
            where: {
                lowercased.contains($0.key)
            }
        ) {
            units = matchedNumber.value
        }

        let numberPattern = #"(\d+)\s*(?:unit|units)"#

        if let regex = try? NSRegularExpression(
            pattern: numberPattern,
            options: [.caseInsensitive]
        ) {
            let range = NSRange(
                cleanTranscript.startIndex..<cleanTranscript.endIndex,
                in: cleanTranscript
            )

            if let match = regex.firstMatch(
                in: cleanTranscript,
                range: range
            ),
               let numberRange = Range(
                    match.range(at: 1),
                    in: cleanTranscript
               ),
               let parsedUnits = Int(
                    cleanTranscript[numberRange]
               )
            {
                units = min(
                    max(parsedUnits, 1),
                    20
                )
            }
        }

        // Basic hospital extraction.
        if hospitalName.isEmpty {
            hospitalName = extractValue(
                afterAnyOf: [
                    "at ",
                    "hospital ",
                    "in "
                ],
                from: cleanTranscript
            )
        }

        // Basic phone-number extraction.
        let phoneDigits = cleanTranscript.filter {
            $0.isNumber
        }

        if contactPhone.isEmpty,
           phoneDigits.count >= 10 {
            contactPhone = String(
                phoneDigits.suffix(10)
            )
        }

        dismiss()
    }

    private func extractValue(
        afterAnyOf prefixes: [String],
        from text: String
    ) -> String {
        let lowercased = text.lowercased()

        for prefix in prefixes {
            guard let range = lowercased.range(
                of: prefix
            ) else {
                continue
            }

            let value = text[range.upperBound...]
                .trimmingCharacters(
                    in: .whitespacesAndNewlines
                )

            guard !value.isEmpty else {
                continue
            }

            let cleanedValue = String(value)
                .components(separatedBy: ".")
                .first?
                .trimmingCharacters(
                    in: .whitespacesAndNewlines
                ) ?? ""

            if !cleanedValue.isEmpty {
                return cleanedValue
            }
        }

        return ""
    }
}

// MARK: - Speech Manager

@MainActor
final class VoiceRequestSpeechManager: NSObject,
    ObservableObject,
    SFSpeechRecognizerDelegate
{
    @Published private(set) var isRecording = false
    @Published private(set) var transcript = ""

    private let audioEngine = AVAudioEngine()

    private let speechRecognizer =
        SFSpeechRecognizer(
            locale: Locale(identifier: "en-US")
        )

    private var recognitionRequest:
        SFSpeechAudioBufferRecognitionRequest?

    private var recognitionTask:
        SFSpeechRecognitionTask?

    private var transcriptHandler:
        ((String) -> Void)?

    private var errorHandler:
        ((String) -> Void)?

    override init() {
        super.init()
        speechRecognizer?.delegate = self
    }

    // MARK: - Start Recording

    func startRecording(
        onTranscript: @escaping (String) -> Void,
        onError: @escaping (String) -> Void
    ) {
        transcriptHandler = onTranscript
        errorHandler = onError
        transcript = ""

        Task { @MainActor in
            do {
                try await requestPermissions()
                try startAudioRecognition()
            } catch {
                onError(error.localizedDescription)
            }
        }
    }

    // MARK: - Stop Recording

    func stopRecording() {
        if audioEngine.isRunning {
            audioEngine.stop()
        }

        audioEngine.inputNode.removeTap(onBus: 0)

        recognitionRequest?.endAudio()
        recognitionTask?.cancel()

        recognitionRequest = nil
        recognitionTask = nil

        isRecording = false

        try? AVAudioSession.sharedInstance()
            .setActive(
                false,
                options: .notifyOthersOnDeactivation
            )
    }

    // MARK: - Permissions

    private func requestPermissions() async throws {
        let speechStatus =
            await requestSpeechAuthorization()

        guard speechStatus == .authorized else {
            throw SpeechError.speechPermissionDenied
        }

        let microphoneAllowed =
            await requestMicrophonePermission()

        guard microphoneAllowed else {
            throw SpeechError.microphonePermissionDenied
        }
    }

    private func requestSpeechAuthorization()
        async -> SFSpeechRecognizerAuthorizationStatus
    {
        await withCheckedContinuation {
            continuation in

            SFSpeechRecognizer.requestAuthorization {
                status in
                continuation.resume(
                    returning: status
                )
            }
        }
    }

    private func requestMicrophonePermission()
        async -> Bool
    {
        await withCheckedContinuation {
            continuation in

            AVAudioSession.sharedInstance()
                .requestRecordPermission { granted in
                    continuation.resume(
                        returning: granted
                    )
                }
        }
    }

    // MARK: - Audio Recognition

    private func startAudioRecognition() throws {
        guard let speechRecognizer,
              speechRecognizer.isAvailable else {
            throw SpeechError.recognizerUnavailable
        }

        if audioEngine.isRunning {
            stopRecording()
        }

        recognitionRequest =
            SFSpeechAudioBufferRecognitionRequest()

        guard let recognitionRequest else {
            throw SpeechError.requestUnavailable
        }

        recognitionRequest.shouldReportPartialResults = true

        let audioSession =
            AVAudioSession.sharedInstance()

        try audioSession.setCategory(
            .record,
            mode: .measurement,
            options: [.duckOthers]
        )

        try audioSession.setActive(
            true,
            options: .notifyOthersOnDeactivation
        )

        let inputNode = audioEngine.inputNode

        inputNode.removeTap(onBus: 0)

        inputNode.installTap(
            onBus: 0,
            bufferSize: 1_024,
            format: inputNode.outputFormat(forBus: 0)
        ) { [weak self] buffer, _ in
            self?.recognitionRequest?.append(buffer)
        }

        audioEngine.prepare()
        try audioEngine.start()

        isRecording = true

        recognitionTask =
            speechRecognizer.recognitionTask(
                with: recognitionRequest
            ) { [weak self] result, error in
                Task { @MainActor in
                    guard let self else {
                        return
                    }

                    if let result {
                        self.transcript =
                            result.bestTranscription
                            .formattedString

                        self.transcriptHandler?(
                            self.transcript
                        )
                    }

                    if let error {
                        self.stopRecording()

                        self.errorHandler?(
                            error.localizedDescription
                        )
                    }
                }
            }
    }

    // MARK: - Errors

    enum SpeechError: LocalizedError {
        case speechPermissionDenied
        case microphonePermissionDenied
        case recognizerUnavailable
        case requestUnavailable

        var errorDescription: String? {
            switch self {
            case .speechPermissionDenied:
                return "Speech recognition permission was denied. Enable it in Settings."

            case .microphonePermissionDenied:
                return "Microphone permission was denied. Enable it in Settings."

            case .recognizerUnavailable:
                return "Speech recognition is currently unavailable."

            case .requestUnavailable:
                return "Could not create a speech recognition request."
            }
        }
    }
}

#Preview {
    VoiceRequestView(
        hospitalName: .constant(""),
        hospitalAddress: .constant(""),
        contactName: .constant(""),
        contactPhone: .constant(""),
        notes: .constant(""),
        selectedBloodGroup: .constant("O+"),
        units: .constant(1),
        urgency: .constant("Normal")
    )
}
