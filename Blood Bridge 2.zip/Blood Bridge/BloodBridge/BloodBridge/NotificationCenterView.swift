import SwiftUI

struct NotificationCenterView: View {
    @AppStorage("notificationsEnabled")
    private var notificationsEnabled = true

    @State private var notifications: [BloodBridgeNotification] = [
        BloodBridgeNotification(
            title: "Welcome to BloodBridge",
            message: "Complete your profile to make coordination easier.",
            date: .now,
            isRead: false
        )
    ]

    private let background = BloodBridgeStyle.background
    private let card = BloodBridgeStyle.card
    private let gold = BloodBridgeStyle.gold
    private let red = BloodBridgeStyle.red

    var body: some View {
        ZStack {
            background
                .ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    header
                    notificationSettings

                    if notifications.isEmpty {
                        emptyState
                    } else {
                        notificationList
                    }
                }
                .padding(20)
                .padding(.bottom, 30)
            }
        }
        .navigationTitle("Notifications")
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(background, for: .navigationBar)
        .toolbarBackground(.visible, for: .navigationBar)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .tint(gold)
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("BLOODBRIDGE")
                .font(.system(size: 12, weight: .bold))
                .tracking(3)
                .foregroundStyle(gold)

            Text("Notifications")
                .font(.system(size: 30, weight: .bold))
                .foregroundStyle(.white)

            Text("Updates about your requests, offers, and appointments.")
                .font(.subheadline)
                .foregroundStyle(.white.opacity(0.65))
        }
        .padding(.top, 12)
    }

    private var notificationSettings: some View {
        HStack(spacing: 13) {
            Image(systemName: "bell.badge.fill")
                .font(.title3)
                .foregroundStyle(gold)

            VStack(alignment: .leading, spacing: 4) {
                Text("Notifications")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.white)

                Text("Enable updates from BloodBridge.")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.6))
            }

            Spacer()

            Toggle("", isOn: $notificationsEnabled)
                .labelsHidden()
                .tint(red)
        }
        .padding(16)
        .background(card)
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }

    private var notificationList: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Recent Updates")
                    .font(.headline)
                    .foregroundStyle(.white)

                Spacer()

                Button("Mark All Read") {
                    for index in notifications.indices {
                        notifications[index].isRead = true
                    }
                }
                .font(.caption.weight(.semibold))
                .foregroundStyle(gold)
            }

            ForEach(notifications) { notification in
                notificationCard(notification)
            }
        }
    }

    private func notificationCard(
        _ notification: BloodBridgeNotification
    ) -> some View {
        HStack(alignment: .top, spacing: 13) {
            Image(
                systemName: notification.isRead
                ? "bell"
                : "bell.badge.fill"
            )
            .foregroundStyle(notification.isRead ? gold : red)
            .frame(width: 28)

            VStack(alignment: .leading, spacing: 6) {
                Text(notification.title)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.white)

                Text(notification.message)
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.68))

                Text(notification.date.formatted(
                    date: .abbreviated,
                    time: .shortened
                ))
                .font(.caption2)
                .foregroundStyle(.white.opacity(0.45))
            }

            Spacer()
        }
        .padding(16)
        .background(card)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .opacity(notification.isRead ? 0.7 : 1)
    }

    private var emptyState: some View {
        VStack(spacing: 12) {
            Image(systemName: "bell.slash")
                .font(.system(size: 38))
                .foregroundStyle(gold)

            Text("No notifications")
                .font(.headline)
                .foregroundStyle(.white)

            Text("New activity updates will appear here.")
                .font(.subheadline)
                .foregroundStyle(.white.opacity(0.65))
        }
        .frame(maxWidth: .infinity)
        .padding(28)
        .background(card)
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }
}

private struct BloodBridgeNotification: Identifiable {
    let id = UUID()
    let title: String
    let message: String
    let date: Date
    var isRead: Bool
}

#Preview {
    NavigationStack {
        NotificationCenterView()
    }
}
