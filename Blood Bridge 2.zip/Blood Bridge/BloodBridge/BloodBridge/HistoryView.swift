import SwiftUI
import Supabase

// MARK: - History Model

struct HistoryRecord: Identifiable {
    let id: String
    let title: String
    let subtitle: String
    let bloodGroup: String
    let date: Date
    let status: String
}

// MARK: - Supabase Models

private struct HistoryRequest: Decodable {
    let id: UUID
    let requester_id: UUID
    let blood_group: String
    let hospital_name: String
    let city: String
    let status: String
    let created_at: String
}

private struct HistoryResponse: Decodable {
    let id: UUID
    let request_id: UUID
    let donor_id: UUID
    let status: String
    let created_at: String
}

// MARK: - History Page

struct HistoryView: View {
    let role: ActivityRole

    @State private var selectedFilter = "All"
    @State private var records: [HistoryRecord] = []
    @State private var isLoading = false
    @State private var errorMessage: String?

    private let red = Color(red: 0.88, green: 0.12, blue: 0.20)
    private let gold = Color(red: 0.80, green: 0.66, blue: 0.40)
    private let card = Color(red: 0.09, green: 0.09, blue: 0.11)
    private let background = Color(red: 0.035, green: 0.035, blue: 0.045)

    private var isDonor: Bool {
        role == .donor
    }

    private let filters = [
        "All", "Completed", "Cancelled", "Declined"
    ]

    private var filteredRecords: [HistoryRecord] {
        guard selectedFilter != "All" else {
            return records
        }

        return records.filter {
            $0.status.caseInsensitiveCompare(selectedFilter) == .orderedSame
        }
    }

    var body: some View {
        ZStack {
            background.ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    header
                    summaryCard
                    filterSection
                    historySection
                }
                .padding(20)
                .padding(.bottom, 30)
            }
            .refreshable {
                await loadHistory()
            }
        }
        .navigationTitle("History")
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(background, for: .navigationBar)
        .toolbarBackground(.visible, for: .navigationBar)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .tint(gold)
        .task {
            await loadHistory()
        }
    }

    // MARK: - Header

    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("BLOODBRIDGE")
                .font(.system(size: 12, weight: .bold))
                .tracking(3)
                .foregroundStyle(gold)

            Text("History")
                .font(.system(size: 30, weight: .bold))
                .foregroundStyle(.white)

            Text(
                isDonor
                    ? "Review your previous donation activity."
                    : "Review your previous blood requests."
            )
            .font(.subheadline)
            .foregroundStyle(.white.opacity(0.65))

            Button {
                Task {
                    await loadHistory()
                }
            } label: {
                Label("Refresh history", systemImage: "arrow.clockwise")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(gold)
            }
            .disabled(isLoading)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.top, 12)
    }

    // MARK: - Summary

    private var summaryCard: some View {
        HStack {
            VStack(alignment: .leading, spacing: 5) {
                Text("Past Records")
                    .font(.subheadline)
                    .foregroundStyle(.white.opacity(0.7))

                Text("\(records.count)")
                    .font(.system(size: 28, weight: .bold))
                    .foregroundStyle(.white)

                Text(
                    isDonor
                        ? "Your donation offers"
                        : "Your blood requests"
                )
                .font(.caption)
                .foregroundStyle(.white.opacity(0.6))
            }

            Spacer()

            Image(systemName: "clock.arrow.circlepath")
                .font(.system(size: 30))
                .foregroundStyle(red)
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(card)
        .clipShape(RoundedRectangle(cornerRadius: 17))
    }

    // MARK: - Filters

    private var filterSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Filter History")
                .font(.headline)
                .foregroundStyle(.white)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(filters, id: \.self) { filter in
                        Button {
                            selectedFilter = filter
                        } label: {
                            Text(filter)
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(.white)
                                .padding(.horizontal, 14)
                                .padding(.vertical, 10)
                                .background(
                                    selectedFilter == filter ? red : card
                                )
                                .clipShape(Capsule())
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    }

    // MARK: - History List

    private var historySection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Previous Activity")
                    .font(.headline)
                    .foregroundStyle(.white)

                Spacer()

                Text("\(filteredRecords.count) records")
                    .font(.caption)
                    .foregroundStyle(gold)
            }

            if isLoading && records.isEmpty {
                ProgressView("Loading history...")
                    .tint(gold)
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding(24)
                    .background(card)
                    .clipShape(RoundedRectangle(cornerRadius: 15))

            } else if let errorMessage {
                VStack(spacing: 12) {
                    Image(systemName: "exclamationmark.triangle")
                        .font(.system(size: 30))
                        .foregroundStyle(gold)

                    Text("Couldn't load history")
                        .font(.headline)
                        .foregroundStyle(.white)

                    Text(errorMessage)
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.7))
                        .multilineTextAlignment(.center)
                        .textSelection(.enabled)

                    Button("Try Again") {
                        Task {
                            await loadHistory()
                        }
                    }
                    .foregroundStyle(gold)
                }
                .frame(maxWidth: .infinity)
                .padding(20)
                .background(card)
                .clipShape(RoundedRectangle(cornerRadius: 15))

            } else if filteredRecords.isEmpty {
                VStack(spacing: 12) {
                    Image(systemName: "clock")
                        .font(.system(size: 30))
                        .foregroundStyle(gold)

                    Text("No past records")
                        .font(.headline)
                        .foregroundStyle(.white)

                    Text(
                        "Records with completed, cancelled, or declined statuses will appear here."
                    )
                    .font(.subheadline)
                    .foregroundStyle(.white.opacity(0.65))
                    .multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity)
                .padding(24)
                .background(card)
                .clipShape(RoundedRectangle(cornerRadius: 15))

            } else {
                ForEach(filteredRecords) { record in
                    historyCard(record)
                }
            }
        }
    }

    // MARK: - History Card

    private func historyCard(_ record: HistoryRecord) -> some View {
        VStack(alignment: .leading, spacing: 13) {
            HStack(alignment: .top, spacing: 12) {
                Image(systemName: "drop.fill")
                    .font(.title2)
                    .foregroundStyle(red)
                    .frame(width: 48, height: 48)
                    .background(red.opacity(0.12))
                    .clipShape(RoundedRectangle(cornerRadius: 13))

                VStack(alignment: .leading, spacing: 5) {
                    Text(record.title)
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.white)

                    Text(record.subtitle)
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.65))
                }

                Spacer(minLength: 4)

                Text(record.status)
                    .font(.system(size: 10, weight: .bold))
                    .foregroundStyle(statusColor(record.status))
                    .padding(.horizontal, 9)
                    .padding(.vertical, 7)
                    .background(statusColor(record.status).opacity(0.12))
                    .clipShape(Capsule())
            }

            Divider()
                .overlay(Color.white.opacity(0.08))

            HStack {
                Label(record.bloodGroup, systemImage: "drop")

                Spacer()

                Text(
                    record.date.formatted(
                        date: .abbreviated,
                        time: .omitted
                    )
                )
            }
            .font(.caption)
            .foregroundStyle(.white.opacity(0.7))
        }
        .padding(15)
        .background(card)
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }

    // MARK: - Status Helpers

    private func normalizedStatus(_ status: String) -> String {
        switch status.lowercased() {
        case "fulfilled", "complete", "completed":
            return "Completed"

        case "cancelled", "canceled":
            return "Cancelled"

        case "declined", "rejected":
            return "Declined"

        default:
            return status.replacingOccurrences(
                of: "_",
                with: " "
            ).capitalized
        }
    }

    private func statusColor(_ status: String) -> Color {
        switch normalizedStatus(status) {
        case "Completed":
            return .green

        case "Cancelled", "Declined":
            return .gray

        default:
            return gold
        }
    }

    private func parseDate(_ value: String) -> Date {
        let formatter = ISO8601DateFormatter()

        formatter.formatOptions = [
            .withInternetDateTime,
            .withFractionalSeconds
        ]

        if let date = formatter.date(from: value) {
            return date
        }

        formatter.formatOptions = [.withInternetDateTime]

        if let date = formatter.date(from: value) {
            return date
        }

        return .now
    }

    // MARK: - Load History

    @MainActor
    private func loadHistory() async {
        guard !isLoading else { return }

        isLoading = true
        errorMessage = nil

        defer {
            isLoading = false
        }

        // currentUser is read synchronously.
        guard let userID = SupabaseManager.client.auth.currentUser?.id else {
            errorMessage = "Please sign in to view your history."
            return
        }

        if isDonor {
            await loadDonorHistory(userID: userID)
        } else {
            await loadRequesterHistory(userID: userID)
        }
    }

    // MARK: - Donor History

    @MainActor
    private func loadDonorHistory(userID: UUID) async {
        do {
            let responses: [HistoryResponse] =
                try await SupabaseManager.client
                    .from("request_responses")
                    .select("id, request_id, donor_id, status, created_at")
                    .eq("donor_id", value: userID.uuidString)
                    .in(
                        "status",
                        values: [
                            "completed",
                            "cancelled",
                            "canceled",
                            "declined"
                        ]
                    )
                    .order("created_at", ascending: false)
                    .execute()
                    .value

            guard !responses.isEmpty else {
                records = []
                return
            }

            let requestIDs: [String] = Array(
                Set(responses.map { $0.request_id.uuidString })
            )

            let requests: [HistoryRequest] =
                try await SupabaseManager.client
                    .from("blood_requests")
                    .select(
                        "id, requester_id, blood_group, hospital_name, city, status, created_at"
                    )
                    .in("id", values: requestIDs)
                    .execute()
                    .value

            // Explicit key/value types prevent generic inference ambiguity.
            let lookup: [UUID: HistoryRequest] = Dictionary(
                uniqueKeysWithValues: requests.map { request in
                    (request.id, request)
                }
            )

            records = responses.compactMap { response -> HistoryRecord? in
                guard let request = lookup[response.request_id] else {
                    return nil
                }	

                return HistoryRecord(
                    id: response.id.uuidString,
                    title: request.hospital_name,
                    subtitle: request.city,
                    bloodGroup: request.blood_group,
                    date: parseDate(response.created_at),
                    status: normalizedStatus(response.status)
                )
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    // MARK: - Requester History

    @MainActor
    private func loadRequesterHistory(userID: UUID) async {
        do {
            let requests: [HistoryRequest] =
                try await SupabaseManager.client
                    .from("blood_requests")
                    .select(
                        "id, requester_id, blood_group, hospital_name, city, status, created_at"
                    )
                    .eq("requester_id", value: userID.uuidString)
                    .in(
                        "status",
                        values: [
                            "completed",
                            "fulfilled",
                            "cancelled",
                            "canceled",
                            "declined"
                        ]
                    )
                    .order("created_at", ascending: false)
                    .execute()
                    .value

            records = requests.map { request in
                HistoryRecord(
                    id: request.id.uuidString,
                    title: "\(request.blood_group) Blood Request",
                    subtitle: "\(request.hospital_name) · \(request.city)",
                    bloodGroup: request.blood_group,
                    date: parseDate(request.created_at),
                    status: normalizedStatus(request.status)
                )
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

// MARK: - Preview

#Preview {
    NavigationStack {
        HistoryView(role: .donor)
    }
}
