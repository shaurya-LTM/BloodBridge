import SwiftUI
import Supabase

struct ContentView: View {
    var onSignedIn: () -> Void = {}

    @State private var isSignUp = false
    @State private var fullName = ""
    @State private var email = ""
    @State private var password = ""
    @State private var showPassword = false

    // Keep only one selectedRole property.
    @State private var selectedRole: ActivityRole = .donor

    @State private var recoveryEmail = ""
    @State private var showRecoverySheet = false

    @State private var alertTitle = ""
    @State private var alertMessage = ""
    @State private var showAlert = false
    @State private var isLoading = false

    private let gold = Color(
        red: 0.78,
        green: 0.57,
        blue: 0.32
    )

    private let backgroundColor = Color(
        red: 0.025,
        green: 0.03,
        blue: 0.035
    )

    var body: some View {
        NavigationStack {
            ZStack {
                backgroundColor
                    .ignoresSafeArea()

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 0) {
                        header

                        BloodBridgeHero(gold: gold)
                            .frame(height: 250)
                            .padding(.top, 12)

                        introduction
                            .padding(.top, 4)

                        authenticationForm
                            .padding(.top, 26)

                        footer
                            .padding(.top, 28)
                            .padding(.bottom, 30)
                    }
                    .padding(.horizontal, 24)
                    .frame(maxWidth: 480)
                    .frame(maxWidth: .infinity)
                }
            }
        }
        .preferredColorScheme(.dark)
        .alert(alertTitle, isPresented: $showAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(alertMessage)
        }
        .sheet(isPresented: $showRecoverySheet) {
            PasswordRecoveryView(
                initialEmail: recoveryEmail
            )
        }
    }

    // MARK: - Header

    private var header: some View {
        HStack(spacing: 12) {
            ZStack {
                Circle()
                    .stroke(gold.opacity(0.8), lineWidth: 1.5)
                    .frame(width: 46, height: 46)

                Image(systemName: "drop.fill")
                    .font(.system(size: 25))
                    .foregroundStyle(
                        LinearGradient(
                            colors: [
                                gold,
                                Color.red.opacity(0.85)
                            ],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )

                Image(systemName: "cross.fill")
                    .font(.system(size: 8, weight: .bold))
                    .foregroundStyle(.white)
            }

            VStack(alignment: .leading, spacing: 2) {
                HStack(spacing: 0) {
                    Text("Blood")
                        .foregroundStyle(.white)

                    Text("Bridge")
                        .foregroundStyle(gold)
                }
                .font(.system(size: 22, weight: .medium))

                Text("P R O J E C T S")
                    .font(.system(size: 9, weight: .medium))
                    .tracking(3.2)
                    .foregroundStyle(.white.opacity(0.65))
            }

            Spacer()

            Text("SAVE LIVES")
                .font(.system(size: 9, weight: .medium))
                .tracking(1.5)
                .foregroundStyle(gold)
        }
        .padding(.top, 18)
        .accessibilityElement(children: .combine)
        .accessibilityLabel("BloodBridge Projects")
    }

    // MARK: - Introduction

    private var introduction: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("TOGETHER WE SAVE LIVES")
                .font(.system(size: 10, weight: .semibold))
                .tracking(3)
                .foregroundStyle(gold)

            VStack(alignment: .leading, spacing: 0) {
                Text("Connecting")
                    .foregroundStyle(.white)

                HStack(spacing: 0) {
                    Text("Donors to ")
                        .foregroundStyle(.white)

                    Text("Life")
                        .foregroundStyle(gold)
                }
            }
            .font(.system(size: 38, weight: .regular))
            .minimumScaleFactor(0.75)
            .lineSpacing(1)
            .fixedSize(horizontal: false, vertical: true)

            Text(
                "Connecting compassionate donors with people " +
                "who need blood, when it matters most."
            )
            .font(.system(size: 14))
            .foregroundStyle(.white.opacity(0.68))
            .lineSpacing(5)
            .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    // MARK: - Login and Sign Up

    private var authenticationForm: some View {
        VStack(spacing: 18) {
            HStack(spacing: 28) {
                modeButton(
                    title: "Login",
                    selected: !isSignUp
                ) {
                    isSignUp = false
                }

                modeButton(
                    title: "Sign Up",
                    selected: isSignUp
                ) {
                    isSignUp = true
                }

                Spacer()
            }

            if isSignUp {
                Picker(
                    "Account Type",
                    selection: $selectedRole
                ) {
                    Text("Blood Donor")
                        .tag(ActivityRole.donor)

                    Text("Healthcare Requester")
                        .tag(ActivityRole.healthcareRequester)
                }
                .pickerStyle(.segmented)
                .tint(gold)

                inputField(
                    icon: "person",
                    placeholder: "Full name",
                    text: $fullName
                )
                .textContentType(.name)
            }

            inputField(
                icon: "envelope",
                placeholder: "Email address",
                text: $email
            )
            .textInputAutocapitalization(.never)
            .keyboardType(.emailAddress)
            .textContentType(.emailAddress)
            .autocorrectionDisabled()

            HStack(spacing: 12) {
                Image(systemName: "lock")
                    .foregroundStyle(gold.opacity(0.9))
                    .frame(width: 20)

                Group {
                    if showPassword {
                        TextField(
                            "Password",
                            text: $password
                        )
                    } else {
                        SecureField(
                            "Password",
                            text: $password
                        )
                    }
                }
                .textContentType(
                    isSignUp
                    ? .newPassword
                    : .password
                )
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()

                Button {
                    showPassword.toggle()
                } label: {
                    Image(
                        systemName: showPassword
                        ? "eye"
                        : "eye.slash"
                    )
                    .foregroundStyle(.white.opacity(0.6))
                }
                .accessibilityLabel(
                    showPassword
                    ? "Hide password"
                    : "Show password"
                )
            }
            .padding(.horizontal, 16)
            .frame(height: 54)
            .background(Color.white.opacity(0.025))
            .clipShape(RoundedRectangle(cornerRadius: 13))
            .overlay {
                RoundedRectangle(cornerRadius: 13)
                    .stroke(
                        Color.white.opacity(0.12),
                        lineWidth: 1
                    )
            }

            if !isSignUp {
                HStack {
                    Spacer()

                    Button("Forgot your password?") {
                        recoveryEmail = email
                        showRecoverySheet = true
                    }
                    .font(.system(size: 12))
                    .foregroundStyle(gold)
                }
            }

            Button {
                validateForm()
            } label: {
                HStack(spacing: 12) {
                    Spacer()

                    if isLoading {
                        ProgressView()
                            .tint(.black)
                    } else {
                        Text(
                            isSignUp
                            ? "Create Account"
                            : "Login"
                        )
                        .font(
                            .system(
                                size: 15,
                                weight: .semibold
                            )
                        )

                        Image(systemName: "arrow.right")
                            .font(
                                .system(
                                    size: 13,
                                    weight: .semibold
                                )
                            )
                    }

                    Spacer()
                }
                .foregroundStyle(Color.black)
                .frame(height: 54)
                .background(
                    LinearGradient(
                        colors: [
                            Color(
                                red: 0.86,
                                green: 0.66,
                                blue: 0.43
                            ),
                            gold
                        ],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .clipShape(RoundedRectangle(cornerRadius: 13))
            }
            .buttonStyle(.plain)
            .disabled(isLoading)

            HStack(spacing: 12) {
                Rectangle()
                    .fill(Color.white.opacity(0.12))
                    .frame(height: 1)

                Text("OR")
                    .font(.system(size: 10))
                    .foregroundStyle(.white.opacity(0.5))

                Rectangle()
                    .fill(Color.white.opacity(0.12))
                    .frame(height: 1)
            }

            Button {
                presentAlert(
                    title: "Google Sign-In",
                    message: "Google sign-in has not been configured yet."
                )
            } label: {
                HStack(spacing: 12) {
                    Text("G")
                        .font(.system(size: 19, weight: .bold))
                        .foregroundStyle(.white)

                    Text("Continue with Google")
                        .font(.system(size: 14))
                        .foregroundStyle(.white.opacity(0.85))
                }
                .frame(maxWidth: .infinity)
                .frame(height: 52)
                .background(Color.clear)
                .overlay {
                    RoundedRectangle(cornerRadius: 13)
                        .stroke(
                            Color.white.opacity(0.22),
                            lineWidth: 1
                        )
                }
            }
            .buttonStyle(.plain)
        }
    }

    // MARK: - Reusable Components

    private func modeButton(
        title: String,
        selected: Bool,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            VStack(spacing: 9) {
                Text(title)
                    .font(
                        .system(
                            size: 14,
                            weight: selected
                            ? .semibold
                            : .regular
                        )
                    )
                    .foregroundStyle(
                        selected
                        ? gold
                        : Color.white.opacity(0.5)
                    )

                Rectangle()
                    .fill(selected ? gold : Color.clear)
                    .frame(height: 2)
            }
            .fixedSize(horizontal: true, vertical: false)
        }
        .buttonStyle(.plain)
    }

    private func inputField(
        icon: String,
        placeholder: String,
        text: Binding<String>
    ) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .foregroundStyle(gold.opacity(0.9))
                .frame(width: 20)

            TextField(
                placeholder,
                text: text
            )
            .textFieldStyle(.plain)
        }
        .padding(.horizontal, 16)
        .frame(height: 54)
        .background(Color.white.opacity(0.025))
        .clipShape(RoundedRectangle(cornerRadius: 13))
        .overlay {
            RoundedRectangle(cornerRadius: 13)
                .stroke(
                    Color.white.opacity(0.12),
                    lineWidth: 1
                )
        }
    }

    private var footer: some View {
        VStack(spacing: 8) {
            Text("REAL PEOPLE / REAL DONATIONS / REAL IMPACT")
                .font(.system(size: 9, weight: .medium))
                .tracking(1.1)
                .foregroundStyle(gold.opacity(0.8))
                .multilineTextAlignment(.center)

            Text("Every drop can make a difference.")
                .font(.system(size: 12))
                .foregroundStyle(.white.opacity(0.45))
        }
        .frame(maxWidth: .infinity)
    }

    // MARK: - Form Validation

    private func validateForm() {
        let trimmedEmail = email.trimmingCharacters(
            in: .whitespacesAndNewlines
        )

        let trimmedName = fullName.trimmingCharacters(
            in: .whitespacesAndNewlines
        )

        guard !trimmedEmail.isEmpty,
              !password.isEmpty else {
            presentAlert(
                title: "Missing Information",
                message: "Please enter your email address and password."
            )
            return
        }

        guard trimmedEmail.contains("@"),
              trimmedEmail.contains(".") else {
            presentAlert(
                title: "Invalid Email",
                message: "Please enter a valid email address."
            )
            return
        }

        if isSignUp && trimmedName.isEmpty {
            presentAlert(
                title: "Missing Name",
                message: "Please enter your full name."
            )
            return
        }

        guard password.count >= 8 else {
            presentAlert(
                title: "Password Too Short",
                message: "Please use at least 8 characters."
            )
            return
        }

        Task {
            await authenticate(
                email: trimmedEmail,
                name: trimmedName,
                password: password
            )
        }
    }

    // MARK: - Supabase Authentication

    @MainActor
    private func authenticate(
        email: String,
        name: String,
        password: String
    ) async {
        guard !isLoading else {
            return
        }

        isLoading = true

        defer {
            isLoading = false
        }

        do {
            if isSignUp {
                let result =
                    try await SupabaseManager.client.auth.signUp(
                        email: email,
                        password: password,
                        data: [
                            "full_name": .string(name),

                            // This sends either:
                            // donor
                            // healthcare_requester
                            "role": .string(
                                selectedRole.rawValue
                            )
                        ]
                    )

                if result.session != nil {
                    onSignedIn()
                } else {
                    presentAlert(
                        title: "Verify Your Email",
                        message: "Your account was created. Check your email for the confirmation link, then return and log in."
                    )

                    isSignUp = false
                    self.password = ""
                }
            } else {
                _ = try await SupabaseManager.client.auth.signIn(
                    email: email,
                    password: password
                )

                onSignedIn()
            }
        } catch {
            presentAlert(
                title: isSignUp
                ? "Signup Failed"
                : "Login Failed",
                message: error.localizedDescription
            )
        }
    }

    private func presentAlert(
        title: String,
        message: String
    ) {
        alertTitle = title
        alertMessage = message
        showAlert = true
    }
}

#Preview {
    ContentView()
}
