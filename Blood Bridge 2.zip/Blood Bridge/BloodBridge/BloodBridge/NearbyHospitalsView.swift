import SwiftUI
import MapKit
import CoreLocation
import Combine

struct NearbyHospitalsView: View {
    @StateObject private var locationManager =
        NearbyHospitalLocationManager()

    @State private var hospitals: [HospitalResult] = []
    @State private var isSearching = false
    @State private var errorMessage = ""

    private let background = BloodBridgeStyle.background
    private let card = BloodBridgeStyle.card
    private let gold = BloodBridgeStyle.gold
    private let red = BloodBridgeStyle.red

    var body: some View {
        ZStack {
            background
                .ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    header

                    Button {
                        Task {
                            await searchNearbyHospitals()
                        }
                    } label: {
                        HStack(spacing: 10) {
                            if isSearching {
                                ProgressView()
                                    .tint(.white)
                            } else {
                                Image(systemName: "location.fill")
                            }

                            Text(
                                isSearching
                                ? "Searching..."
                                : "Find Nearby Hospitals"
                            )
                            .fontWeight(.semibold)
                        }
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 15)
                        .background(red)
                        .clipShape(
                            RoundedRectangle(cornerRadius: 13)
                        )
                    }
                    .disabled(isSearching)

                    if !errorMessage.isEmpty {
                        Text(errorMessage)
                            .font(.caption)
                            .foregroundStyle(.orange)
                    }

                    if hospitals.isEmpty && !isSearching {
                        emptyState
                    } else {
                        hospitalList
                    }
                }
                .padding(20)
                .padding(.bottom, 30)
            }
        }
        .navigationTitle("Nearby Hospitals")
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(background, for: .navigationBar)
        .toolbarBackground(.visible, for: .navigationBar)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .tint(gold)
    }

    // MARK: - Header

    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("BLOODBRIDGE")
                .font(.system(size: 12, weight: .bold))
                .tracking(3)
                .foregroundStyle(gold)

            Text("Nearby Hospitals")
                .font(.system(size: 30, weight: .bold))
                .foregroundStyle(.white)

            Text("Find hospitals near your current location.")
                .font(.subheadline)
                .foregroundStyle(.white.opacity(0.65))
        }
        .padding(.top, 12)
    }

    // MARK: - Empty State

    private var emptyState: some View {
        VStack(spacing: 12) {
            Image(systemName: "cross.case.fill")
                .font(.system(size: 42))
                .foregroundStyle(gold)

            Text("No hospitals loaded")
                .font(.headline)
                .foregroundStyle(.white)

            Text(
                "Tap the button above to search for hospitals near you."
            )
            .font(.subheadline)
            .foregroundStyle(.white.opacity(0.65))
            .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(28)
        .background(card)
        .clipShape(
            RoundedRectangle(cornerRadius: 17)
        )
    }

    // MARK: - Hospital List

    private var hospitalList: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Nearby Results")
                .font(.headline)
                .foregroundStyle(.white)

            ForEach(hospitals) { hospital in
                hospitalCard(hospital)
            }
        }
    }

    private func hospitalCard(
        _ hospital: HospitalResult
    ) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top, spacing: 12) {
                Image(systemName: "cross.case.fill")
                    .font(.title3)
                    .foregroundStyle(red)
                    .frame(width: 40, height: 40)
                    .background(red.opacity(0.12))
                    .clipShape(Circle())

                VStack(alignment: .leading, spacing: 5) {
                    Text(hospital.name)
                        .font(.headline)
                        .foregroundStyle(.white)

                    if let address = hospital.address,
                       !address.isEmpty {
                        Text(address)
                            .font(.subheadline)
                            .foregroundStyle(.white.opacity(0.68))
                    }
                }

                Spacer(minLength: 0)
            }

            Button {
                openInMaps(hospital)
            } label: {
                Label("Open in Maps", systemImage: "map")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(gold)
            }
            .buttonStyle(.plain)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(card)
        .clipShape(
            RoundedRectangle(cornerRadius: 17)
        )
    }

    // MARK: - Search

    @MainActor
    private func searchNearbyHospitals() async {
        errorMessage = ""
        hospitals = []
        isSearching = true

        defer {
            isSearching = false
        }

        do {
            let coordinate =
                try await locationManager.currentLocation()

            let request = MKLocalSearch.Request()
            request.naturalLanguageQuery = "hospital"
            request.region = MKCoordinateRegion(
                center: coordinate,
                latitudinalMeters: 10_000,
                longitudinalMeters: 10_000
            )

            let response =
                try await MKLocalSearch(request: request).start()

            hospitals = response.mapItems.compactMap { item in
                let name = item.name ?? "Hospital"
                let address = item.address?.fullAddress

                return HospitalResult(
                    name: name,
                    address: address,
                    coordinate: item.location.coordinate
                )
            }

            if hospitals.isEmpty {
                errorMessage = "No hospitals were found nearby."
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    // MARK: - Maps

    private func openInMaps(
        _ hospital: HospitalResult
    ) {
        let location = CLLocation(
            latitude: hospital.coordinate.latitude,
            longitude: hospital.coordinate.longitude
        )

        let mapItem = MKMapItem(
            location: location,
            address: nil
        )

        mapItem.name = hospital.name
        mapItem.openInMaps(
            launchOptions: [
                MKLaunchOptionsDirectionsModeKey:
                    MKLaunchOptionsDirectionsModeDriving
            ]
        )
    }
}

// MARK: - Hospital Model

private struct HospitalResult: Identifiable {
    let id = UUID()
    let name: String
    let address: String?
    let coordinate: CLLocationCoordinate2D
}

// MARK: - Location Manager

final class NearbyHospitalLocationManager:
    NSObject,
    ObservableObject,
    CLLocationManagerDelegate
{
    private let manager = CLLocationManager()

    private var locationContinuation:
        CheckedContinuation<CLLocationCoordinate2D, Error>?

    override init() {
        super.init()

        manager.delegate = self
        manager.desiredAccuracy =
            kCLLocationAccuracyHundredMeters
    }

    func currentLocation() async throws
        -> CLLocationCoordinate2D
    {
        let authorizationStatus =
            manager.authorizationStatus

        switch authorizationStatus {
        case .denied, .restricted:
            throw LocationError.permissionDenied

        case .notDetermined:
            manager.requestWhenInUseAuthorization()

        case .authorizedAlways, .authorizedWhenInUse:
            break

        @unknown default:
            throw LocationError.unavailable
        }

        return try await withCheckedThrowingContinuation {
            continuation in

            self.locationContinuation = continuation

            if manager.authorizationStatus == .authorizedAlways ||
               manager.authorizationStatus == .authorizedWhenInUse {
                manager.requestLocation()
            }
        }
    }

    func locationManagerDidChangeAuthorization(
        _ manager: CLLocationManager
    ) {
        switch manager.authorizationStatus {
        case .authorizedAlways, .authorizedWhenInUse:
            manager.requestLocation()

        case .denied, .restricted:
            locationContinuation?.resume(
                throwing: LocationError.permissionDenied
            )

            locationContinuation = nil

        default:
            break
        }
    }

    func locationManager(
        _ manager: CLLocationManager,
        didUpdateLocations locations: [CLLocation]
    ) {
        guard let location = locations.last else {
            locationContinuation?.resume(
                throwing: LocationError.unavailable
            )

            locationContinuation = nil
            return
        }

        locationContinuation?.resume(
            returning: location.coordinate
        )

        locationContinuation = nil
    }

    func locationManager(
        _ manager: CLLocationManager,
        didFailWithError error: Error
    ) {
        locationContinuation?.resume(
            throwing: error
        )

        locationContinuation = nil
    }
}

// MARK: - Location Errors

private enum LocationError: LocalizedError {
    case permissionDenied
    case unavailable

    var errorDescription: String? {
        switch self {
        case .permissionDenied:
            return """
            Location permission is disabled. Enable location access in Settings.
            """

        case .unavailable:
            return """
            Your current location could not be determined. Please try again.
            """
        }
    }
}

// MARK: - Preview

#Preview {
    NavigationStack {
        NearbyHospitalsView()
    }
}
