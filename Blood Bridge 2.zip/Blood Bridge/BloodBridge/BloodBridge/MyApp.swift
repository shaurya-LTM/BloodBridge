import SwiftUI

@main
struct BloodBridgeApp: App {
    var body: some Scene {
        WindowGroup {
            LaunchScreenView()
        }
    }
}
