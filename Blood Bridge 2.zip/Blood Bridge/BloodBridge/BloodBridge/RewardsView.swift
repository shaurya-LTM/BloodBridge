import SwiftUI
import Supabase

struct RewardsView: View {
    @State private var rewardPoints = 0
    @State private var completedDonations = 0
    @State private var rewardHistory: [RewardRecord] = []

    @State private var isLoading = false
    @State private var errorMessage = ""

    private let background = BloodBridgeStyle.background
    private let card = BloodBridgeStyle.card
    private let gold = BloodBridgeStyle.gold
    private let red = BloodBridgeStyle.red

    private var donorLevel: String {
        switch completedDonations {
        case 0:
            return "New Donor"
        case 1...2:
            return "Life Helper"
        case 3...4:
            return "Life Saver"
        default:
            return "BloodBridge Champion"
        }
    }

    private var nextMilestone: Int {
        if completedDonations < 1 {
            return 1
        } else if completedDonations < 3 {
            return 3
        } else if completedDonations < 5 {
            return 5
        } else {
            return completedDonations + 5
        }
    }

    private var progress: Double {
        guard nextMilestone > 0 else {
            return 0
        }

        return min(
            Double(completedDonations) /
                Double(nextMilestone),
            1
        )
    }

    var body: some View {
        ZStack {
            background
                .ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    header
                    scoreCard
                    milestoneCard
                    historySection
                }
                .padding(20)
                .padding(.bottom, 30)
            }
            .refreshable {
                await loadRewards()
            }
        }
        .navigationTitle("Rewards")
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(background, for: .navigationBar)
        .toolbarBackground(.visible, for: .navigationBar)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .tint(gold)
        .task {
            await loadRewards()
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("BLOODBRIDGE")
                .font(.system(size: 12, weight: .bold))
                .tracking(3)
                .foregroundStyle(gold)

            Text("Donor Rewards")
                .font(.system(size: 30, weight: .bold))
                .foregroundStyle(.white)

            Text(
                "Every completed donation makes a measurable difference."
            )
            .font(.subheadline)
            .foregroundStyle(.white.opacity(0.65))
        }
        .padding(.top, 12)
    }

    private var scoreCard: some View {
        VStack(spacing: 16) {
            HStack {
                VStack(alignment: .leading, spacing: 5) {
                    Text("Current Level")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.65))

                    Text(donorLevel)
                        .font(.title2.bold())
                        .foregroundStyle(.white)

                    Text(
                        "\(completedDonations) completed donation\(completedDonations == 1 ? "" : "s")"
                    )
                    .font(.subheadline)
                    .foregroundStyle(.white.opacity(0.65))
                }

                Spacer()

                Image(systemName: "trophy.fill")
                    .font(.system(size: 38))
                    .foregroundStyle(gold)
            }

            Divider()
                .overlay(.white.opacity(0.1))

            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Reward Points")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.65))

                    Text("\(rewardPoints)")
                        .font(.system(size: 38, weight: .bold))
                        .foregroundStyle(gold)
                }

                Spacer()

                Image(systemName: "star.circle.fill")
                    .font(.system(size: 35))
                    .foregroundStyle(red)
            }
        }
        .padding(20)
        .background(card)
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .overlay {
            RoundedRectangle(cornerRadius: 20)
                .stroke(gold.opacity(0.25), lineWidth: 1)
        }
    }

    private var milestoneCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Next Milestone")
                    .font(.headline)
                    .foregroundStyle(.white)

                Spacer()

                Text("\(completedDonations)/\(nextMilestone)")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(gold)
            }

            ProgressView(value: progress)
                .tint(gold)

            Text(
                "\(max(nextMilestone - completedDonations, 0)) more completed donation\(nextMilestone - completedDonations == 1 ? "" : "s") to reach the next level."
            )
            .font(.caption)
            .foregroundStyle(.white.opacity(0.65))
        }
        .padding(18)
        .background(card)
        .clipShape(RoundedRectangle(cornerRadius: 17))
    }

    private var historySection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Reward History")
                .font(.headline)
                .foregroundStyle(.white)

            if isLoading && rewardHistory.isEmpty {
                ProgressView("Loading rewards...")
                    .tint(gold)
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding(24)
                    .background(card)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
            } else if !errorMessage.isEmpty {
                VStack(spacing: 10) {
                    Image(systemName: "exclamationmark.triangle")
                        .foregroundStyle(.orange)

                    Text(errorMessage)
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.7))
                        .multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity)
                .padding(24)
                .background(card)
                .clipShape(RoundedRectangle(cornerRadius: 16))
            } else if rewardHistory.isEmpty {
                Text(
                    "Complete your first donation to start earning rewards."
                )
                .font(.subheadline)
                .foregroundStyle(.white.opacity(0.65))
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(18)
                .background(card)
                .clipShape(RoundedRectangle(cornerRadius: 16))
            } else {
                ForEach(rewardHistory) { reward in
                    rewardRow(reward)
                }
            }
        }
    }

    private func rewardRow(
        _ reward: RewardRecord
    ) -> some View {
        HStack(spacing: 13) {
            Image(systemName: "star.fill")
                .foregroundStyle(gold)
                .frame(width: 34, height: 34)
                .background(gold.opacity(0.12))
                .clipShape(Circle())

            VStack(alignment: .leading, spacing: 4) {
                Text(reward.reason)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.white)

                Text(
                    reward.createdAt.formatted(
                        date: .abbreviated,
                        time: .shortened
                    )
                )
                .font(.caption)
                .foregroundStyle(.white.opacity(0.55))
            }

            Spacer()

            Text("+\(reward.points)")
                .font(.headline.weight(.bold))
                .foregroundStyle(gold)
        }
        .padding(15)
        .background(card)
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }

    @MainActor
    private func loadRewards() async {
        guard let userID =
            SupabaseManager.client.auth.currentUser?.id else {
            errorMessage = "Please sign in to view your rewards."
            return
        }

        isLoading = true
        errorMessage = ""

        defer {
            isLoading = false
        }

        do {
            let profiles: [RewardProfile] =
                try await SupabaseManager.client
                    .from("profiles")
                    .select(
                        "reward_points, completed_donations"
                    )
                    .eq(
                        "id",
                        value: userID.uuidString
                    )
                    .limit(1)
                    .execute()
                    .value

            rewardPoints =
                profiles.first?.rewardPoints ?? 0

            completedDonations =
                profiles.first?.completedDonations ?? 0

            rewardHistory =
                try await SupabaseManager.client
                    .from("reward_ledger")
                    .select(
                        "id, points, reason, created_at"
                    )
                    .eq(
                        "donor_id",
                        value: userID.uuidString
                    )
                    .order(
                        "created_at",
                        ascending: false
                    )
                    .execute()
                    .value
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

private struct RewardProfile: Decodable {
    let rewardPoints: Int?
    let completedDonations: Int?

    enum CodingKeys: String, CodingKey {
        case rewardPoints = "reward_points"
        case completedDonations = "completed_donations"
    }
}

private struct RewardRecord: Decodable, Identifiable {
    let id: UUID
    let points: Int
    let reason: String
    let createdAt: Date

    enum CodingKeys: String, CodingKey {
        case id
        case points
        case reason
        case createdAt = "created_at"
    }
}

#Preview {
    NavigationStack {
        RewardsView()
    }
}
