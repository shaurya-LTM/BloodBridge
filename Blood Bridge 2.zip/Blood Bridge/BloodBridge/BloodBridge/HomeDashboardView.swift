import SwiftUI
import Supabase

enum BloodBridgeStyle {
    static let background = Color(
        red: 0.025,
        green: 0.03,
        blue: 0.035
    )

    static let card = Color(
        red: 0.055,
        green: 0.06,
        blue: 0.07
    )

    static let gold = Color(
        red: 0.78,
        green: 0.57,
        blue: 0.32
    )

    static let red = Color(
        red: 0.82,
        green: 0.08,
        blue: 0.12
    )

    static let muted = Color.white.opacity(0.58)
}

struct HomeDashboardView: View {
    var onSignedOut: () -> Void = {}

    @State private var showDonorDashboard = false
    @State private var showRequesterDashboard = false

    @State private var userRole: ActivityRole = .donor
    @State private var isLoadingRole = true

    var body: some View {
        ZStack {
            BloodBridgeStyle.background
                .ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 24) {
                    header
                    welcomeSection
                    dashboardSection
                    accountSection
                    informationNotice
                }
                .padding(.horizontal, 20)
                .padding(.top, 12)
                .padding(.bottom, 36)
                .frame(maxWidth: 600)
                .frame(maxWidth: .infinity)
            }
        }
        .preferredColorScheme(.dark)
        .navigationBarBackButtonHidden(true)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .toolbarBackground(
            BloodBridgeStyle.background,
            for: .navigationBar
        )
        .toolbarBackground(.visible, for: .navigationBar)
        .navigationDestination(
            isPresented: $showDonorDashboard
        ) {
            NavigationStack {
                DonorDashboardView()
            }
        }
        .navigationDestination(
            isPresented: $showRequesterDashboard
        ) {
            NavigationStack {
                HealthcareRequesterDashboardView()
            }
        }
        .task {
            await loadRole()
        }
    }

    // MARK: - Load User Role

    @MainActor
    private func loadRole() async {
        isLoadingRole = true
        defer {
            isLoadingRole = false
        }

        guard let user = SupabaseManager.client.auth.currentUser else {
            userRole = .donor
            return
        }

        let roleValue =
            user.userMetadata["role"]?.stringValue ?? "donor"

        userRole =
            ActivityRole(rawValue: roleValue) ?? .donor
    }

    // MARK: - Header

    private var header: some View {
        HStack(spacing: 12) {
            ZStack {
                Circle()
                    .stroke(
                        BloodBridgeStyle.gold,
                        lineWidth: 1.5
                    )
                    .frame(width: 44, height: 44)

                Image(systemName: "heart.fill")
                    .font(.system(size: 21))
                    .foregroundStyle(BloodBridgeStyle.red)

                Image(systemName: "cross.fill")
                    .font(.system(size: 9, weight: .bold))
                    .foregroundStyle(.white)
            }

            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 0) {
                    Text("Blood")
                        .foregroundStyle(.white)

                    Text("Bridge")
                        .foregroundStyle(
                            BloodBridgeStyle.gold
                        )
                }
                .font(.system(size: 22, weight: .medium))

                Text("P R O J E C T S")
                    .font(.system(size: 9))
                    .tracking(2.5)
                    .foregroundStyle(
                        BloodBridgeStyle.muted
                    )
            }

            Spacer()

            NavigationLink {
                AccountLogoutView(
                    role: userRole,
                    onSignedOut: onSignedOut
                )
            } label: {
                Image(
                    systemName: "person.crop.circle"
                )
                .font(.system(size: 21))
                .foregroundStyle(
                    BloodBridgeStyle.gold
                )
                .frame(width: 42, height: 42)
                .background(
                    BloodBridgeStyle.card
                )
                .clipShape(Circle())
            }
            .accessibilityLabel("Account settings")
        }
    }

    // MARK: - Welcome

    private var welcomeSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("WELCOME TO BLOODBRIDGE")
                .font(
                    .system(
                        size: 10,
                        weight: .semibold
                    )
                )
                .tracking(2.5)
                .foregroundStyle(
                    BloodBridgeStyle.gold
                )

            Text("Together, we save lives.")
                .font(
                    .system(
                        size: 29,
                        weight: .medium
                    )
                )
                .foregroundStyle(.white)
                .fixedSize(
                    horizontal: false,
                    vertical: true
                )

            Text(
                "Connect with people who need blood, " +
                "or help coordinate a request when it matters most."
            )
            .font(.system(size: 14))
            .foregroundStyle(
                BloodBridgeStyle.muted
            )
            .lineSpacing(4)
            .fixedSize(
                horizontal: false,
                vertical: true
            )
        }
    }

    // MARK: - Dashboard Section

    private var dashboardSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("YOUR DASHBOARD")
                .font(
                    .system(
                        size: 10,
                        weight: .semibold
                    )
                )
                .tracking(2)
                .foregroundStyle(
                    BloodBridgeStyle.gold
                )

            if isLoadingRole {
                HStack(spacing: 10) {
                    ProgressView()
                        .tint(BloodBridgeStyle.gold)

                    Text("Loading your dashboard...")
                        .font(.subheadline)
                        .foregroundStyle(.white.opacity(0.7))
                }
                .frame(maxWidth: .infinity)
                .padding(22)
                .background(
                    BloodBridgeStyle.card
                )
                .clipShape(
                    RoundedRectangle(cornerRadius: 18)
                )
            } else {
                switch userRole {
                case .donor:
                    dashboardCard(
                        title: "Donor Dashboard",
                        subtitle:
                            "Find open blood requests and offer to donate.",
                        icon: "heart.text.clipboard",
                        isDonor: true
                    ) {
                        showDonorDashboard = true
                    }

                case .healthcareRequester:
                    dashboardCard(
                        title: "Healthcare Requester",
                        subtitle:
                            "Create blood requests and track their status.",
                        icon: "cross.case.fill",
                        isDonor: false
                    ) {
                        showRequesterDashboard = true
                    }
                }
            }
        }
    }

    private func dashboardCard(
        title: String,
        subtitle: String,
        icon: String,
        isDonor: Bool,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Image(systemName: icon)
                        .font(.system(size: 23))
                        .foregroundStyle(
                            isDonor
                            ? BloodBridgeStyle.red
                            : BloodBridgeStyle.gold
                        )
                        .frame(width: 50, height: 50)
                        .background(
                            (
                                isDonor
                                ? BloodBridgeStyle.red
                                : BloodBridgeStyle.gold
                            )
                            .opacity(0.10)
                        )
                        .clipShape(Circle())

                    Spacer()

                    Image(
                        systemName: "arrow.up.right"
                    )
                    .font(
                        .system(
                            size: 15,
                            weight: .semibold
                        )
                    )
                    .foregroundStyle(
                        isDonor
                        ? BloodBridgeStyle.red
                        : BloodBridgeStyle.gold
                    )
                }

                Text(title)
                    .font(
                        .system(
                            size: 18,
                            weight: .semibold
                        )
                    )
                    .foregroundStyle(.white)

                Text(subtitle)
                    .font(.system(size: 13))
                    .foregroundStyle(
                        BloodBridgeStyle.muted
                    )
                    .multilineTextAlignment(.leading)
                    .fixedSize(
                        horizontal: false,
                        vertical: true
                    )

                HStack {
                    Text(
                        isDonor
                        ? "Go to Donor Dashboard"
                        : "Go to Requester Dashboard"
                    )
                    .font(
                        .system(
                            size: 13,
                            weight: .semibold
                        )
                    )

                    Spacer()

                    Image(systemName: "arrow.right")
                }
                .foregroundStyle(
                    isDonor
                    ? BloodBridgeStyle.red
                    : BloodBridgeStyle.gold
                )
                .padding(.top, 3)
            }
            .padding(18)
            .frame(
                maxWidth: .infinity,
                alignment: .leading
            )
            .background(
                LinearGradient(
                    colors: [
                        isDonor
                        ? Color.red.opacity(0.09)
                        : BloodBridgeStyle.gold.opacity(0.08),
                        BloodBridgeStyle.card
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .clipShape(
                RoundedRectangle(cornerRadius: 18)
            )
            .overlay {
                RoundedRectangle(cornerRadius: 18)
                    .stroke(
                        isDonor
                        ? BloodBridgeStyle.red.opacity(0.38)
                        : BloodBridgeStyle.gold.opacity(0.32),
                        lineWidth: 1
                    )
            }
        }
        .buttonStyle(.plain)
    }

    // MARK: - Account

    private var accountSection: some View {
        NavigationLink {
            AccountLogoutView(
                role: userRole,
                onSignedOut: onSignedOut
            )
        } label: {
            HStack(spacing: 13) {
                Image(
                    systemName: "person.crop.circle"
                )
                .font(.title3)
                .foregroundStyle(
                    BloodBridgeStyle.gold
                )

                VStack(alignment: .leading, spacing: 4) {
                    Text("Profile & Account")
                        .font(
                            .subheadline.weight(
                                .semibold
                            )
                        )
                        .foregroundStyle(.white)

                    Text(
                        "Manage your profile, settings and sign-out."
                    )
                    .font(.caption)
                    .foregroundStyle(
                        BloodBridgeStyle.muted
                    )
                }

                Spacer()

                Image(systemName: "chevron.right")
                    .font(
                        .caption.weight(
                            .semibold
                        )
                    )
                    .foregroundStyle(
                        BloodBridgeStyle.muted
                    )
            }
            .padding(16)
            .background(
                BloodBridgeStyle.card
            )
            .clipShape(
                RoundedRectangle(cornerRadius: 15)
            )
        }
        .buttonStyle(.plain)
    }

    // MARK: - Notice

    private var informationNotice: some View {
        HStack(
            alignment: .top,
            spacing: 10
        ) {
            Image(systemName: "info.circle")
                .foregroundStyle(
                    BloodBridgeStyle.gold
                )

            Text(
                "Your dashboard is selected using the role saved in " +
                "your Supabase account. Supabase Row Level Security " +
                "policies should also enforce this role."
            )
            .font(.system(size: 11))
            .foregroundStyle(
                BloodBridgeStyle.muted
            )
            .fixedSize(
                horizontal: false,
                vertical: true
            )
        }
        .padding(14)
        .background(
            Color.white.opacity(0.025)
        )
        .clipShape(
            RoundedRectangle(cornerRadius: 12)
        )
    }
}

#Preview {
    NavigationStack {
        HomeDashboardView()
    }
}
